// AUTO UPDATE
const { TS3QueryClient } = require('@ts3/query-client');
const { ipcRenderer } = require('electron');
const { BrowserWindow } = ipcRenderer;
var fs = require('fs');
var Registry = require('winreg');
var SteamAccount = [];
const homedir = require('os').homedir();
const {shell} = require('electron');

var DIR_FIVEM;
var DIR_TS3;

var rimraf = require("rimraf");
const find = require('find-process');

function GET_STEAM_HEX(callback){
    var regKey = new Registry({
        hive: Registry.HKCU,
        key:  '\\Software\\Valve\\Steam\\ActiveProcess'
    });
    regKey.values(function (err, items) {
        if (err){
            callback("0x0");
        }else{
            for (var i=0; i<items.length; i++){
                if(items[i].name == "ActiveUser"){
                    var steam_id = parseInt(items[i].value, 16);
                    if(items[i].value == 0x0){
                        callback("0x0");
                    }else{
                        callback("steam:1100001" + d2h(steam_id));
                    }
                    break;
                }
            }
        }
    });
}

function GET_STEAM_ID(callback){
    var regKey = new Registry({
        hive: Registry.HKCU,
        key:  '\\Software\\Valve\\Steam\\ActiveProcess'
    });
    regKey.values(function (err, items) {
        if (err){
            callback("0x0");
        }else{
            for (var i=0; i<items.length; i++){
                if(items[i].name == "ActiveUser"){
                    var steam_id = parseInt(items[i].value, 16);
                    if(items[i].value == 0x0){
                        callback("0x0");
                    }else{
                        callback(steam_id);
                    }
                    break;
                }
            }
        }
    });
}


function SET_DIR_FIVEM(value){
    // fs.readFile(__dirname + "//config.json", 'utf8', function readFileCallback(err, data){
    //     if (err){
    //         console.log(err);
    //     } else {
    //     obj = JSON.parse(data); //now it an object
    //     obj.DIR_FIVEM = value
    //     json = JSON.stringify(obj, null, 4); //convert it back to json
    //     fs.writeFile(__dirname + "//config.json", json, 'utf8', err => {
    //         if (err) return console.error('File write error:', err);
    //     });
    // }});
    DIR_FIVEM = value
}

function SET_DIR_TS3(value){
    DIR_TS3 = value
    // fs.readFile(__dirname + "//config.json", 'utf8', function readFileCallback(err, data){
    //     if (err){
    //         console.log(err);
    //     } else {
    //     obj = JSON.parse(data); //now it an object
    //     obj.DIR_TS3 = value
    //     json = JSON.stringify(obj, null, 4); //convert it back to json
    //     fs.writeFile(__dirname + "//config.json", json, 'utf8', err => {
    //         if (err) return console.error('File write error:', err);
    //     });
    // }});
}

function GET_DIR_FIVEM(){

    var Registry = require('winreg'), regKey = new Registry({
        hive: Registry.HKCU,
        key:  '\\Software\\CitizenFX\\FiveM\\'
    });

    regKey.values(function (err, items) {

        if (err){
            SET_DIR_FIVEM("NO_DIR");
        }else{
            for (var i=0; i<items.length; i++){
                if(items[i].name == "Last Run Location"){
                    SET_DIR_FIVEM(items[i].value);
                }
                break;
            }
        }
    });

}

function GET_DIR_TS3(){

    var Registry = require('winreg'), regKey = new Registry({
        hive: Registry.HKLM,
        key:  '\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\TeamSpeak 3 Client'
    });

    regKey.values(function (err, items) {
        if (err){
            SET_DIR_TS3("NO_DIR");
        }else{
            for (var i=0; i<items.length; i++){
                if(items[i].name == "InstallLocation"){
                    SET_DIR_TS3(items[i].value);
                    break;
                }
            }
        }
    });

}

function CHECK_STEAM_IS_OPENNING_BACKGROUND(){
    GET_STEAM_HEX(function (steamhex){
        if(steamhex == "0x0"){
            const remote = require('electron').remote;
            var win = remote.getCurrentWindow();
            win.reload();
        }
    });
}


function CHECK_STEAM_IS_OPENNING(){
    GET_STEAM_HEX(function (steamhex){
        if(steamhex == "0x0"){
            $("#main_page").hide();
            $("#steam_message").html("");
            $("#steam_message").html(
                '<div align="center" style="margin-bottom: 2vh;">' + 
                    '<i class="fab fa-steam fa-9x"></i>' + 
                '</div>' + 
                '<span class="white-text" style="font-weight: 400;font-size: 3vh;">กรุณาเปิด Steam ก่อนใช้งาน MEETA</span>' 
            ).fadeIn('fast');
            $("#btn-library").prop('disabled', true);

            setInterval(CHECK_STEAM_IS_OPENNING(), 10000);

        }else{

            setInterval(function(){ CHECK_STEAM_IS_OPENNING_BACKGROUND(); }, 10000);

            $("#steam_message").hide();

            CREATE_LIBRARY();

            $("#btn-library").prop('disabled', false);

        }
    });
}


function CREATE_LIBRARY(){
    
    fs.readFile(__dirname + "\\library.html", function (err, data) {
        GET_DATA_STEAM();
        $(".loading").fadeIn('fast');
        setTimeout(function(){
            $("#main_page").hide().html(data.toString()).fadeIn('fast');
        }, 2000);
    });
}

function GET_DATA_STEAM(){
    GET_STEAM_ID(function (steamhex){
        var SteamID = require('steamid');
        var sid = new SteamID('[U:1:' + steamhex + ']');
        if(steamhex != "0x0"){
            $.ajax({
                url: "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/?key=D6140FC42E635E983873F5247792D087&format=json&steamids=" + sid,
            }).done(function (data) {
                SteamAccount["avatar"] = data['response']['players'][0]['avatarfull'];
                SteamAccount["name"] = data['response']['players'][0]['personaname'];

                SET_PROFILE();
            });
        }
    });
}

function SET_PROFILE(){
    $("#profile_avatar").attr("src", SteamAccount["avatar"]);
    $("#profile_name").html(SteamAccount["name"]);
    $("#profile").fadeIn('fast');
}


$(function(){
    //Check Update

    $.ajax({
        dataType: "json",
        url: "https://dev.promraungdet.com/fivem/Update.json",
        cache: false,
        success: function(json){
            // setInterval(() => {
            //     GET_DIR_TS3();
            //     GET_DIR_FIVEM();
            // }, 5000);
            
            // CHECK_STEAM_IS_OPENNING();
        
            // GET_DATA_STEAM();


            $("#btn-library").prop('disabled', true);
            $("#main_page").hide();
            $("#steam_message").html("");
            $("#steam_message").html(
                '<div align="center" style="margin-bottom: 2vh;">' + 
                    '<div class="ball-beat"><div></div><div></div><div></div></div>' + 
                '</div>' + 
                '<span class="white-text" style="font-weight: 400;font-size: 3vh;">กำลังตรวจสอบเวอร์ชั่น</span>' 
            ).fadeIn('fast');

            $.getJSON(__dirname + "\\config.json", function(data) {
                $.each(json, function( index, value ) {
                    var current_version = data.VERSION;
                    var check_version = index;
                    if (current_version < check_version){
                        setTimeout(function(){
                            $("#steam_message").html(
                                '<div align="center" style="margin-bottom: 2vh;">' + 
                                    '<div class="ball-beat"><div></div><div></div><div></div></div>' + 
                                '</div>' + 
                                '<div class="white-text" style="font-weight: 400;font-size: 3vh;">กำลังอัพเดทเวอร์ชั่น ' + check_version + '</div>' + 
                                '<div class="white-text" style="font-weight: 400;font-size: 2.5vh;" id="txt_download"></div>' + 
                                '<input type="hidden" id="txt_version" value="' + check_version + '" />'
                            ).fadeIn('fast');

                           
                            if (fs.existsSync(__dirname + "\\downloads\\" + check_version + ".zip")){
                                fs.unlinkSync(__dirname + "\\downloads\\" + check_version + ".zip");
                            }

                            //Download
                            ipcRenderer.send("download", {
                                url: value.file,
                                properties: {directory: __dirname + "\\downloads\\"}
                            });
                        }, 1000);
                        return false;
                    }else{
                        
                        $("#btn-library").prop('disabled', false);

                        setInterval(() => {
                            GET_DIR_TS3();
                            GET_DIR_FIVEM();
                        }, 5000);
                        
                        CHECK_STEAM_IS_OPENNING();
                    
                        GET_DATA_STEAM();
                        return false;
                    }
                });
            }).fail(function(jqXHR, textStatus, errorThrown) {
                $("#main_page").hide();
                $("#steam_message").html("");
                $("#steam_message").html(
                    '<div align="center" style="margin-bottom: 2vh;">' + 
                        '<i class="fas fa-comment-alt fa-9x"></i>' + 
                    '</div>' + 
                    '<span class="white-text" style="font-weight: 400;font-size: 3vh;">' + errorThrown + '</span>' 
                ).fadeIn('fast');
                $("#btn-library").prop('disabled', true);
            });


        }
    }).fail(function( jqxhr, textStatus, error ) {
        $("#main_page").hide();
        $("#steam_message").html("");
        $("#steam_message").html(
            '<div align="center" style="margin-bottom: 2vh;">' + 
                '<i class="fas fa-download fa-9x"></i>' + 
            '</div>' + 
            '<span class="white-text" style="font-weight: 400;font-size: 3vh;">ไม่สามารถเชื่อมต่อกับเซิฟเวอร์อัพเดทได้ กรุณาลองใหม่ภายหลัง</span>' 
        ).fadeIn('fast');
        $("#btn-library").prop('disabled', true);
    });

    // $.getJSON("https://raw.githubusercontent.com/promraungdet/Pracharath-Update/master/update.json", function( data ) {
    // //$.getJSON("http://192.168.1.2/update.json", function( data ) {
    //     const {app} = require('electron').remote;
    //     const CurrentVersion = app.getVersion();
    //     const NewVersion = data.version;
    //     const URL = data.url + NewVersion + ".zip";
        
    //     if(NewVersion > CurrentVersion){

    //         $("#txt_version").val(NewVersion);

    //         $("#button-start").attr('disabled','disabled');
    //         $("#message").text("���ѧ�ӡ���Ѿഷ...");

    //         //Update Progressbar
    //         $(".progress-bar").css('width', '0px');
    //         ipcRenderer.send("download", {
    //             url: URL,
    //             properties: {directory: __dirname}
    //         });

    //     }else{
    //         $('#text_version').text(CurrentVersion);
    //         $("#message").text("�����������ش����.");
    //         $(".progress-bar").css('width', '100%');
    //         $("#button-start").prop('disabled', false);
    //     }

    // });

    
    $('body').on('click', '#delete-cache', function(){

        // $.getJSON(__dirname + "\\config.json", function(json) {
        //     var dir1 = json.DIR_FIVEM + "\\cache\\browser";
        //     var dir2 = json.DIR_FIVEM + "\\cache\\db";
        //     var dir3 = json.DIR_FIVEM + "\\cache\\priv";
        //     var dir4 = json.DIR_FIVEM + "\\cache\\servers";
        //     var dir5 = json.DIR_FIVEM + "\\cache\\subprocess";
        //     var dir6 = json.DIR_FIVEM + "\\cache\\unconfirmed"
        //     rimraf(dir1, function () { console.log("done"); });
        //     rimraf(dir2, function () { console.log("done"); });
        //     rimraf(dir3, function () { console.log("done"); });
        //     rimraf(dir4, function () { console.log("done"); });
        //     rimraf(dir5, function () { console.log("done"); });
        //     rimraf(dir6, function () { console.log("done"); });
        //     rimraf(json.DIR_FIVEM + "\\cache\\crashometry", function () { console.log("done"); });
        //     rimraf(json.DIR_FIVEM + "\\cache\\launcher_skip_mtl2", function () { console.log("done"); });
        //     $.alert({
        //         title: 'แจ้งเตือน!',
        //         theme: 'black',
        //         columnClass: 'col-md-12',
        //         draggable: false,
        //         content: 'ล้าง Cache FiveM ของคุณเรียบร้อยแล้ว',
        //     });
        // });
        var dir1 = DIR_FIVEM + "\\cache\\browser";
        var dir2 = DIR_FIVEM + "\\cache\\db";
        var dir3 = DIR_FIVEM + "\\cache\\priv";
        var dir4 = DIR_FIVEM + "\\cache\\servers";
        var dir5 = DIR_FIVEM + "\\cache\\subprocess";
        var dir6 = DIR_FIVEM + "\\cache\\unconfirmed"
        rimraf(dir1, function () { console.log("done"); });
        rimraf(dir2, function () { console.log("done"); });
        rimraf(dir3, function () { console.log("done"); });
        rimraf(dir4, function () { console.log("done"); });
        rimraf(dir5, function () { console.log("done"); });
        rimraf(dir6, function () { console.log("done"); });
        rimraf(DIR_FIVEM + "\\cache\\crashometry", function () { console.log("done"); });
        rimraf(DIR_FIVEM + "\\cache\\launcher_skip_mtl2", function () { console.log("done"); });
        $.alert({
            title: 'แจ้งเตือน!',
            theme: 'black',
            columnClass: 'col-md-12',
            draggable: false,
            content: 'ล้าง Cache FiveM ของคุณเรียบร้อยแล้ว',
        });

    });

    $('body').on('click', '#open-fivem', function(){

        // $.getJSON("config.json", function(json) {
        //     if (fs.existsSync(json.DIR_FIVEM)){
        //         shell.openItem(json.DIR_FIVEM);
        //     }
        // });
        if (fs.existsSync(DIR_FIVEM)){
            shell.openItem(DIR_FIVEM);
        }

    });

    $('body').on('click', '#btn-play', function(){
        var serverAdress = $(this).attr('data-game');
        var serverAdressTS3 = $(this).attr('data-ts3');
        StartFiveM(serverAdress, serverAdressTS3);
    });

     $('body').on('click', '#copy-steamId', function(){
        CopySteamId();
    });

    $('body').on('click', '#help', function(){
        shell.openExternal("https://dev.promraungdet.com/%e0%b9%80%e0%b8%81%e0%b8%b5%e0%b9%88%e0%b8%a2%e0%b8%a7%e0%b8%81%e0%b8%b1%e0%b8%9a%e0%b9%80%e0%b8%a3%e0%b8%b2/");
    });

    $('body').on('click', '#btn-ts3', function(){

        var serverAdressTS3 = $(this).attr('data-ts3');

        $.getJSON("config.json", function(json) {
            if (!fs.existsSync(DIR_TS3)){
                shell.openExternal(__dirname + "\\" + json["add-on"]["teamspeak3"]["file"]);
                $("#btn-ts3").prop('disabled', true);
            }else{
                if (fs.existsSync(homedir + "\\AppData\\Roaming\\TS3Client\\plugins\\tokovoip_win64.dll")) {
                    StartTeamSpeak(serverAdressTS3);
                    $("#btn-ts3").prop('disabled', true);
                    setTimeout(function(){
                        $("#btn-ts3").prop('disabled', false);
                    }, 2000);
                }else{
                    $("#btn-ts3").prop('disabled', true);
                    find('name', 'ts3client_win64.exe').then(function (list) {
                        if(list.length == 1){
                            $.alert({
                                title: 'แจ้งเตือน!',
                                theme: 'black',
                                columnClass: 'col-md-12',
                                draggable: false,
                                content: 'คุณต้องปิด Teamspeak 3 ก่อนติดตั้ง TokoVoip',
                            });
                            // TEXT_BUTTON_TS3 = "ปิด Teamspeak 3 ก่อนติดตั้ง";
                            // $("#btn-ts3").html('<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> ' + TEXT_BUTTON_TS3);
                            // $("#btn-ts3").prop('disabled', true);
                            setTimeout(function(){
                                TEXT_BUTTON_TS3 = "ติดตั้ง TokoVoip 1.5.0 (Teamspeak 3)";
                                $("#btn-ts3").html('<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> ' + TEXT_BUTTON_TS3);
                            }, 2000);
                        }else{
                            let spawn = require("child_process").spawn;
                            spawn(DIR_TS3 + "\\package_inst.exe", [
                                __dirname + "\\" + json["add-on"]["tokovoip"]["file"]
                            ]);
                            $("#btn-ts3").prop('disabled', true);
                        }
                    });
                    
                }
            }
        });
        
    });

    $('body').on('click', '[data-action="view"]', function(){
        var id = $(this).attr('data-id');
        $("#main_page").fadeOut('fast');
        $("#main_page").html('');
        $(".loading").fadeIn('fast');
        setTimeout(function(){
            $.ajax({
                dataType: "json",
                url: "https://dev.promraungdet.com/fivem/Library.json",
                cache: false,
                success: function(data){
                    DataList = data
                    $(".loading").fadeOut('fast');
                    var value = DataList[id];
                    var html = '<div class="library-view" align="left" style="background:url(' + value.banner + ');background-position: center;background-size: 100% auto;"><div class="banner-gradient"></div></div>' + 
                        //'<img src="' + value.cover + '" alt="' + value.name + '" class="img-thumbnail banner-view" draggable="false" style="width: 20vh;height: auto;">' + 
                        '<div class="carda">' + 
                            '<div class="acard scard__one">' + 
                                '<div class="acard__bg" style="background: url(' + value.cover_bg +') center / cover no-repeat;"></div>' + 
                                '<img class="acard__img" src="' + value.cover + '" draggable="false"/>' + 
                                '<div class="acard__text">' + 
                                    '<p class="acard__title"></p>' + 
                                '</div>' + 
                            '</div>' + 
                        '</div>' + 
                        '<span class="library-view-title">' + value.name + ' <i class="fas fa-check-circle"></i></span><span id="steam_id"></span>';

                    html += '<div class="library_other">' + 
                                    '<button id="btn-play" data-game="' + value.serverAdress + '" data-ts3="' + value.ts3.serverAdress + '" class="btn btn-success btn-lg" disabled="disabled"><i class="fas fa-play" style="margin-right: 0.5vh"></i> ' + TEXT_BUTTON_PLAY + '</button>' + 
                                    '<button id="btn-ts3" data-ts3="' + value.ts3.serverAdress + '" class="btn btn-info btn-lg" disabled="disabled"><i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> ' + TEXT_BUTTON_TS3 + ' Teamspeak 3</button>' + 
                                    '<button class="btn btn-secondary dropdown-toggle btn-lg" id="dropdownMenuButton1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-cog" style="margin-right: 0.5vh"></i> อื่นๆ</button>' + 
                                    '<div class="dropdown-menu dropdown-menu-inverse" aria-labelledby="dropdown-' + id +'">' + 
                                        '<a class="dropdown-item" id="delete-cache" href="#" draggable="false"><span>ล้าง Cache</span></a>' + 
                                        '<a class="dropdown-item" id="open-fivem" href="#" draggable="false"><span>เปิดโฟลเดอร์ FiveM</span></a>' + 
                                        '<a class="dropdown-item" id="copy-steamId" href="#" draggable="false"><span>คัดลอก Steam Id ของฉัน</span></a>' + 
                                        '<a class="dropdown-item" id="help" href="#" draggable="false"><span>ช่วยเหลือ</span></a>' + 
                                    '</div>' + 
                                '</div>'

                    // Description
                    if (value.description){
                        html += '<div class="library_desct_text">' + atob(value.description) + ' </div>';
                    }
                     // Addon
                    var count = Object.keys(value.addon).length;
                    if(count >= 1){
                        html += '<div class="library_addon_text">ส่วนเสริม</div>';
                        $.each(value.addon, function( index, value ) {
                            html += '<div class="library_addon">' + 
                                            '<div class="list" data-action="addon_view" data-id="' + id + '" data-addon="' + index + '">' + 
                                                '<img src="' + value.cover + '" alt="' + value.name + '" class="img-thumbnail addons-view" draggable="false" style="width: 30vh;height: 17vh;">' + 
                                                '<div class="title">' + value.name + '</div>'
                                            '</div>'
                                        '<div>';
                        });
                    }

                    
                    

                    $("#main_page").html(html).fadeIn('fast');
                    $('#dropdown-' + id).dropdown();

                    $("#btn-play").prop('disabled', true);
                    $("#btn-ts3").prop('disabled', true);

                    $("#btn-play").html('<i class="fas fa-play" style="margin-right: 0.5vh"></i> ' + TEXT_BUTTON_PLAY);
                    $("#btn-ts3").html('<i class="fab fa-teamspeak" style="margin-right: 0.5vh" disabled="disabled"></i> ' + TEXT_BUTTON_TS3);

                    GET_DIR_INSTALLED();

                    GET_STEAM_HEX(function (steamhex){
                        $("#steam_id").text(steamhex);
                    });

                    setInterval(() => {
                        GET_DIR_INSTALLED();
                    }, 5000);

                    const cards = document.querySelector(".carda");
                    const images = document.querySelectorAll(".acard__img");
                    const backgrounds = document.querySelectorAll(".acard__bg");
                    const range = 10;

                    // const calcValue = (a, b) => (((a * 100) / b) * (range / 100) -(range / 2)).toFixed(1);
                    const calcValue = (a, b) => (a/b*range-range/2).toFixed(1) // thanks @alice-mx

                    let timeout;
                    $( "body" ).mousemove(function( event ) {
                        if (timeout) {
                            window.cancelAnimationFrame(timeout);
                        }
                            
                        timeout = window.requestAnimationFrame(() => {
                            const yValue = calcValue(event.clientY, window.innerHeight);
                            const xValue = calcValue(event.clientX, window.innerWidth);

                            cards.style.transform = `rotateX(${yValue}deg) rotateY(${xValue}deg)`;

                            [].forEach.call(images, (image) => {
                                image.style.transform = `translateX(${-xValue}px) translateY(${yValue}px)`;
                            });

                            [].forEach.call(backgrounds, (background) => {
                                background.style.backgroundPosition = `${xValue*.45}px ${-yValue*.45}px`;
                            })
                        })
                    });

                }
            });
        }, 1000);
    });
    
    $('body').on('click', '[data-action="addon_view"]', function(){
        var id = $(this).attr('data-id');
        var addon = $(this).attr('data-addon');
        $.ajax({
            dataType: "json",
            url: "https://dev.promraungdet.com/fivem/Library.json",
            cache: false,
            success: function(data){
                DataList = data
                var value = DataList[id].addon[addon];
                if(value.url_download === false){
                    $.alert({
                        title: value.name,
                        theme: 'black',
                        columnClass: 'col-md-12',
                        draggable: false,
                        content: '<iframe width="100%" height="512" src="' + value.preview + '" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>',
                        buttons: {
                            youtube: {
                                text: '<i class="fab fa-youtube"></i> ดูบน Youtube', // With spaces and symbols
                                action: function () {
                                    shell.openExternal(value.preview);
                                }
                            },
                            close: {
                                text: 'ปิด', // With spaces and symbols
                                action: function () {
                                    
                                }
                            }
                        }
                    });
                    
                }
            }
        });
    });


});

ipcRenderer.on("download progress", (event, progress) => {
    const cleanProgressInPercentages = Math.floor(progress.percent * 100); // Without decimal point
    $("#txt_download").text("กำลังดาวน์โหลด " + cleanProgressInPercentages + "%");
    // $(".progress-bar").css('width', cleanProgressInPercentages + '%');
    // $("#version").text(cleanProgressInPercentages+ '%');
});

ipcRenderer.on("download complete", (event, file) => {

    var DecompressZip = require('decompress-zip');
    var ZIP_FILE_PATH = file;
    var DESTINATION_PATH = __dirname;
    var unzipper = new DecompressZip(ZIP_FILE_PATH);
    
    unzipper.on('error', function (err) {
        $("#txt_download").text("ผิดพลาด: " + err);
    });
    
    unzipper.on('progress', function (fileIndex, fileCount) {
        $("#txt_download").text("กำลังติดตั้งไฟล์ " + (fileIndex + 1) + '/' + fileCount);

        if((fileIndex + 1) == fileCount){ //Extract Success


            fs.readFile(__dirname + "//config.json", 'utf8', function readFileCallback(err, data){
                if (err){
                    console.log(err);
                } else {
                obj = JSON.parse(data); //now it an object
                obj.VERSION = $("#txt_version").val();
                json = JSON.stringify(obj, null, 4); //convert it back to json
                fs.writeFile(__dirname + "//config.json", json, 'utf8', err => {
                    if (err) return console.error('File write error:', err);
                });
            }});

            setTimeout(function(){
                fs.unlinkSync(file);
                const {app} = require('electron').remote;
                app.relaunch();
                app.exit();
            }, 2000);
        }

    });

    unzipper.extract({
        path: DESTINATION_PATH
    });
    
});

// unzipper.on('error', function (err) {
//     $("#message").text("Error: " + err);
// });

// unzipper.on('progress', function (fileIndex, fileCount) {
//     $("#message").text("���ѧ�Դ������  " + (fileIndex + 1) + ' of ' + fileCount);
// });

//END UPDATE

function AppMaximize(){
    const remote = require('electron').remote;
    var win = remote.getCurrentWindow();
    win.minimize();
}

function AppClosed(){
    const remote = require('electron').remote.app;
    // let w = remote.getCurrentWindow();
    // w.close();
    remote.quit();
}

function StartFiveM(ip, ts3){

    $("#button-start").attr('disabled','disabled');
    $("#button-start").text('CHECKING...');

    $.getJSON("config.json", function(json) {
        for (i = 0; i < json["check"].files.length; i++) {

            var FILE_NAME = json["check"].files[i];
            var FOLDER_NAME = json["check"].folder;
            var DIR_TARGET = DIR_FIVEM; //+ DIR_NAME + "\\";

            if(!fs.existsSync(DIR_TARGET + FILE_NAME)) {
                var fss = require('fs-extra');
                fss.copy(__dirname + "\\files\\" + FOLDER_NAME, DIR_TARGET); 

                StartFiveM_2(ip, ts3);

                break;
            }else{
                StartFiveM_2(ip, ts3)
            }
        }
    });
}

function StartFiveM_2(ip, ts3){
    $.getJSON("config.json", function(json) {
        var fivem_frame = document.createElement('iframe');
        fivem_frame.style.display = 'none';
        fivem_frame.onload = function() { fivem_frame.parentNode.removeChild(fivem_frame); };
        fivem_frame.src = atob(ip);
        document.body.appendChild(fivem_frame);
        StartTeamSpeak(ts3);
        setTimeout(function(){
            $("#button-start").prop("disabled", false);
            $("#button-start").text('START GAME');
        }, 5000);
    });
}

function StartTeamSpeak(ts3){
    $.getJSON("config.json", function(json) {
        var ts_frame = document.createElement('iframe');
        ts_frame.style.display = 'none';
        ts_frame.onload = function() { ts_frame.parentNode.removeChild(ts_frame); };
        ts_frame.src = atob(ts3);
        document.body.appendChild(ts_frame);
    });
}

$(function(){

    $("#btn-library").on('click', function(){
        $("#main_page").hide();
        $("#steam_message").html("");
        fs.readFile(__dirname + "\\library.html", function (err, data) {
            GET_DATA_STEAM();
            $(".loading").fadeIn('fast');
            setTimeout(function(){
                $("#main_page").hide().html(data.toString()).fadeIn('fast');
            }, 2000);
        });
    });

    $("#button-settings").on('click', function(){
        const electron = require('electron');
        const path = require('path');
        const BrowserWindow = electron.remote.BrowserWindow;
        const modalPath = path.join('file://', __dirname, 'settings.html');
        let win = new BrowserWindow({ 
            width: 400, 
            height: 600, 
            frame: false, 
            resizable: false, 
            skipTaskbar: true, 
            webPreferences: {
                nodeIntegration: true
            }
        });
        win.loadURL(modalPath);
        win.show();

        GET_STEAM_HEX(function (steamhex){
            win.webContents.on('did-finish-load', () => {
                if(steamhex == "0x0"){
                    win.webContents.send("steam-id", "0x0");
                }else{
                    win.webContents.send("steam-id", steamhex);
                }
            })
        });
    });
});

function d2h(s) {
    var a = s.toString(16);
    if ((a.length % 2) > 0) {
        a = "0" + a;
    }
    return a;
}