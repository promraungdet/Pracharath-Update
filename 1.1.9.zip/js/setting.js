var software_installed = '<i class="fas fa-check text-success"></i>';
var software_not_install = '<i class="fas fa-times text-danger" style="margin-right: 2px;"></i>';
var fs = require('fs');

function SET_DIR_FIVEM(value){
    fs.readFile(__dirname + "//config.json", (err, buffer) => {
        if (err) return console.error('File read error: ', err)
        
        const data = JSON.parse(buffer.toString())
        
        data.DIR_FIVEM = value
        
        fs.writeFile(__dirname + "//config.json", JSON.stringify(data, null, 4), err => {
            if (err) return console.error('File write error:', err);
        });
    });
}

function GET_DIR_FIVEM(){

    var Registry = require('winreg'), regKey = new Registry({
        hive: Registry.HKCU,
        key:  '\\Software\\CitizenFX\\FiveM\\'
    });

    regKey.values(function (err, items) {

        if (err){
            SET_DIR_FIVEM("NO_DIR");
        }else{
            for (var i=0; i<items.length; i++){
                if(items[i].name == "Last Run Location"){
                    SET_DIR_FIVEM(items[i].value);
                    break;
                }
            }
        }
    });
}

function copyFolderRecursiveSync( source, target ) {
    var files = [];

    //check if folder needs to be created or integrated
    var targetFolder = path.join( target, path.basename( source ) );
    if ( !fs.existsSync( targetFolder ) ) {
        fs.mkdirSync( targetFolder );
    }

    //copy
    if ( fs.lstatSync( source ).isDirectory() ) {
        files = fs.readdirSync( source );
        files.forEach( function ( file ) {
            var curSource = path.join( source, file );
            if ( fs.lstatSync( curSource ).isDirectory() ) {
                copyFolderRecursiveSync( curSource, targetFolder );
            } else {
                copyFileSync( curSource, targetFolder );
            }
        } );
    }
}

$(function(){

    const homedir = require('os').homedir();

    try {
        if (fs.existsSync(homedir + "\\AppData\\Roaming\\TS3Client\\plugins\\tokovoip_win64.dll")) {
            $("#ts_plugin_text").html(software_installed);
        }else{
            $("#ts_plugin_text").html(software_not_install);
        }

    }catch(err) {
        $("#ts_plugin_text").html(software_not_install);
    }

    //Loading Mods list
    GET_DIR_FIVEM();

    $.getJSON("config.json", function(json) {

        if (!fs.existsSync(json.DIR_FIVEM)){
            var temp = '<li class="list-group-item" style="font-size: 14px;">' + 
                                '<span class="red-text">�س�ѧ�����Դ��� FiveM</span>'
                            '</li>';

            $("#list_mods").append(temp);
        }

        $.each(json["add-on"], function(index, item) {

            var checked = "";

            for (i = 0; i < item.files.length; i++) {
                if(!fs.existsSync(json.DIR_FIVEM + item.files[i])) {
                    checked = "";
                    break;
                }else{
                    checked = "checked";
                }
            } 
            
            var temp = '<li class="list-group-item" style="font-size: 14px;">' + 
                                '<i class="fas fa-tv" style="margin-right: 5px;"></i> ' + item.title +
                                '<div style="position: absolute;top: 15px;right: 15px;">' + 
                                    '<label class="custom-toggle">' + 
                                        '<input type="checkbox" data-value="graphics" '+ checked +'>' + 
                                        '<span class="custom-toggle-slider rounded-circle"></span>' + 
                                    '</label>' + 
                                '</div>' + 
                            '</li>';
            
            $("#list_mods").append(temp);

        });

        //Action
        $('input[type="checkbox"]').on('click', function(){

            var name = $(this).attr('data-value');
            $(this).attr('disabled','disabled');
            
            if(json["add-on"][name]){
                if($(this).is(":checked")){
                    for (i = 0; i < json["add-on"][name].files.length; i++) {

                        var FILE_NAME = json["add-on"][name].files[i];
                        var FOLDER_NAME = json["add-on"][name].folder;
                        var DIR_NAME = FILE_NAME.substring(0, FILE_NAME.lastIndexOf('/')) + "/";
                        var DIR_TARGET = json.DIR_FIVEM; //+ DIR_NAME + "\\";
                
                        var fileNameIndex = FILE_NAME.lastIndexOf("/") + 1;
                        var filename = FILE_NAME.substr(fileNameIndex);

                        var fss = require('fs-extra');
                        fss.copy(__dirname + "\\files\\" + FOLDER_NAME, DIR_TARGET); 
                        $(this).prop('disabled', false);
                    }
                }else{
                    try {

                        for (i = 0; i < json["add-on"][name].files.length; i++) {

                            var FILE_NAME = json["add-on"][name].files[i];
                            var DIR_NAME = FILE_NAME.substring(0, FILE_NAME.lastIndexOf('/')) + "/";
                            var DIR_TARGET = json.DIR_FIVEM + DIR_NAME + "\\";
                    
                            var fileNameIndex = FILE_NAME.lastIndexOf("/") + 1;
                            var filename = FILE_NAME.substr(fileNameIndex);

                            fs.unlinkSync(DIR_TARGET + filename);

                            $(this).prop('disabled', false);
                        }

                        

                    } catch(err) {
                        $(this).prop('disabled', false);
                    }
                }
            }

        });
    });

});

require('electron').ipcRenderer.on('teamspeak', (event, bool) => {
    if(bool){
        $("#ts_text").html(software_installed);
    }else{
        $("#ts_text").html(software_not_install);
    }
});

require('electron').ipcRenderer.on('steam-id', (event, message) => {
    if(message == 0x0){
        $("#steam_id").html('<span class="text-danger">�س�ѧ�����Դ��� Steam ���� �Դ Steam</span>');
        $("#button-copy").hide();
    }else{
        $("#steam_id").html(message);
        $("#button-copy").show();
    }
})

function AppClosed(){
    const remote = require('electron').remote
    let w = remote.getCurrentWindow();
    w.close();
}

function CopySteamId(){
    CopyToClipboard("steam_id");
}

function CopyToClipboard(containerid) {
    if (document.selection) { 
        var range = document.body.createTextRange();
        range.moveToElementText(document.getElementById(containerid));
        range.select().createTextRange();
        document.execCommand("copy"); 
        $("#show_text_copy").fadeIn('slow');
        setTimeout(function(){
            $("#show_text_copy").fadeOut('slow');
        }, 2000);
    } else if (window.getSelection) {
        var range = document.createRange();
        range.selectNode(document.getElementById(containerid));
        window.getSelection().addRange(range);
        document.execCommand("copy");
        $("#show_text_copy").fadeIn('slow');
        setTimeout(function(){
            $("#show_text_copy").fadeOut('slow');
        }, 2000);
    }
}