const { app, BrowserWindow, ipcMain } = require('electron');
const {download} = require("electron-dl");
const url = require('url');
const path = require('path');
let $ = require('jquery');

let win  

function createWindow() { 
    win = new BrowserWindow({
        width: 800, 
        height: 500, 
        webPreferences: {nodeIntegration: true}, 
        frame: false, 
        resizable: false
    }) 
    win.setFullScreen(false);
    win.setMenuBarVisibility(false);
    win.loadURL(url.format ({ 
        pathname: path.join(__dirname, 'index.html'), 
        protocol: 'file:', 
        slashes: true,
        frame: false,
        toolbar: false
    }));
    // win.minWidth = 1600
    // win.maxHeight = 900
    // win.setSize(1368, 720)
    // win.setResizable(true);
    win.maximize();
    // win.webContents.openDevTools();
}

const gotTheLock = app.requestSingleInstanceLock()

if (!gotTheLock) {
    app.quit()
} else {
    app.on('second-instance', (event, commandLine, workingDirectory) => {
        // Someone tried to run a second instance, we should focus our window.
        if (win) {
        if (win.isMinimized()) win.restore()
            win.focus()
        }
    })

  // Create myWindow, load the rest of the app, etc...
  app.on('ready', () => {
    createWindow();
    ipcMain.on("download", (event, info) => {
        info.properties.onProgress = status => win.webContents.send("download progress", status);
        download(BrowserWindow.getFocusedWindow(), info.url, info.properties)
            .then(dl => win.webContents.send("download complete", dl.getSavePath()));
    });
  })
}

// app.on('ready', () => {
    
// });
  
app.on('window-all-closed', function () {
    if (process.platform !== 'darwin') {
      	app.quit();
    }
});
  
app.on('activate', function () {
    if (mainWindow === null) {
      	createWindow();
    }
});

app.on('after-create-window', function () {
    // https://github.com/marcbachmann/electron-rpc
    server.configure(app.window.webContents);
    // https://github.com/romanschejbal/electron-blog/issues/2
    // and https://github.com/electron/electron/issues/1344#issuecomment-208839713
    const handleRedirect = (e, url) => {
      if (url !== app.window.webContents.getURL()) {
        e.preventDefault();
        shell.openExternal(url)
      }
    };
    app.window.webContents.on('will-navigate', handleRedirect);
    app.window.webContents.on('new-window', handleRedirect);
});