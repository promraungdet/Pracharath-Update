// AUTO UPDATE
const { ipcRenderer } = require('electron');
const child_process = require('child_process');
const fs = require('fs');
var regedit = require('regedit');
var remote_file = require('remote-file-size');
var ini = require('ini');

var Registry = require('winreg');
var SteamAccount = [];

const homedir = require('os').homedir();
const {shell} = require('electron');
const clipboardy = require('clipboardy');
var AdmZip = require('adm-zip');

var request = require('request');
var progress = require('request-progress');
const checkDiskSpace = require('check-disk-space');

var DIR_GAME;
var DIR_TS3;
var DIR_STEAM;
var IS_DISABLE_SYNC_TS3 = false;
var URL_Update = 'https://app-meeta.io/fivem/Update.json';
var URL_Library = 'https://app-meeta.io/fivem/Library.json';
var URL_Download = 'https://app-meeta.io/fivem/Downloads.json';
var URL_Notices = 'https://app-meeta.io/fivem/Notices.json';

var SteamState = {
    [0]: "offline",
    [1]: "online",
    [3]: "away"
}

var rimraf = require("rimraf");
const find = require('find-process');

function GET_STEAM_HEX(callback){
    var regKey = new Registry({
        hive: Registry.HKCU,
        key:  '\\Software\\Valve\\Steam\\ActiveProcess'
    });
    regKey.values(function (err, items) {
        if (err){
            callback("0x0");
        }else{
            for (var i=0; i<items.length; i++){
                if(items[i].name == "ActiveUser"){
                    var steam_id = parseInt(items[i].value, 16);
                    if(items[i].value == 0x0){
                        callback("0x0");
                    }else{
                        SteamAccount["uid"] = "steam:1100001" + d2h(steam_id);
                        callback("steam:1100001" + d2h(steam_id));
                    }
                    break;
                }
            }
        }
    });
}

function GET_STEAM_ID(callback){
    var regKey = new Registry({
        hive: Registry.HKCU,
        key:  '\\Software\\Valve\\Steam\\ActiveProcess'
    });
    regKey.values(function (err, items) {
        if (err){
            callback("0x0");
        }else{
            for (var i=0; i<items.length; i++){
                if(items[i].name == "ActiveUser"){
                    var steam_id = parseInt(items[i].value, 16);
                    if(items[i].value == 0x0){
                        callback("0x0");
                    }else{
                        callback(steam_id);
                    }
                    break;
                }
            }
        }
    });
}


function SET_DIR_GAME(value){
    DIR_GAME = value;
}

function SET_DIR_TS3(value){
    DIR_TS3 = value
}

function SET_DIR_STEAM(value){
    DIR_STEAM = value
}

function GET_DIR_GAME(type, dir, value){
    var dir_reg = `${type}${dir}`;
    regedit.list(dir_reg, function(err, result) {
        $.each(result, function(index, data) {
            if (data.values[value].value) {
                SET_DIR_GAME(data.values[value].value);
                return;
            }
            SET_DIR_GAME("NO_DIR");
        });
    });

}

function GET_DIR_STEAM(){

    var dir_reg = `HKCU\\Software\\Valve\\Steam`;
    regedit.list(dir_reg, function(err, result) {
        $.each(result, function(index, data) {
            if (data.values["SteamPath"].value) {
                SET_DIR_STEAM(data.values["SteamPath"].value);
                return;
            }
            SET_DIR_STEAM("NO_DIR");
        });
    });
}

function GET_DIR_TS3(){

    var Registry = require('winreg'), regKey = new Registry({
        hive: Registry.HKLM,
        key:  '\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\TeamSpeak 3 Client'
    });

    regKey.values(function (err, items) {
        if (err){
            SET_DIR_TS3("NO_DIR");
        }else{
            for (var i=0; i<items.length; i++){
                if(items[i].name == "InstallLocation"){
                    SET_DIR_TS3(items[i].value);
                    break;
                }
            }
        }
    });

}

function CHECK_STEAM_IS_OPENNING_BACKGROUND(){
    GET_STEAM_HEX(function (steamhex){
        if(steamhex == "0x0"){
            const remote = require('electron').remote;
            var win = remote.getCurrentWindow();
            win.reload();
        }
    });
}

function SET_MESSAGE_ERROR(msg){
    $("#main_page").hide();
    $("#main_page_view").hide();
    $("#message_error").html("");
    $("#message_error").html(msg).fadeIn('fast');
    $("[data-disabled]").prop('disabled', true);
}

function CHECK_STEAM_IS_OPENNING(){
    GET_STEAM_HEX(function (steamhex){
        if(steamhex == "0x0"){
            var message = `<div align="center" style="margin-bottom: 2vh;">
                                            <i class="fab fa-steam fa-9x"></i>
                                    </div>
                                    <span class="white-text" style="font-weight: 400;font-size: 1vw;">กรุณาเปิด Steam ก่อนใช้งาน MEETA</span>`;
            SET_MESSAGE_ERROR(message);
            $("[data-disabled]").prop('disabled', true);

            setInterval(CHECK_STEAM_IS_OPENNING(), 10000);

        }else{

            setInterval(function(){ CHECK_STEAM_IS_OPENNING_BACKGROUND(); }, 10000);

            setInterval(function(){ GET_DATA_STEAM(); }, 30000);

            $("#message_error").hide();

            CREATE_LIBRARY();
            CREATE_NOTICES();

            $("[data-disabled]").prop('disabled', false);

        }
    });
}

function CREATE_NOTICES(){
    $.ajax({
        dataType: "json",
        url: URL_Notices,
        cache: false,
        success: function(json){
            
            $.each(json, function(index, data) {
                // console.log(index);
                var checkLocal = localStorage.getItem(index.toString());
                if (checkLocal === null){
                    $(".notices-icon").css("color", "#f44336");
                } else {
                    $(".notices-icon").css("color", "#fff");
                }
            });
        }
    });
}

function CREATE_LIBRARY(){
    
    fs.readFile(__dirname + "\\library.html", function (err, data) {
        GET_DATA_STEAM();
        GET_DIR_STEAM();
        $(".loading").fadeIn('fast');
        $("[data-disabled]").prop('disabled', true);
        setTimeout(function(){
            $("#main_page").hide().html(data.toString()).fadeIn('fast');
            $("[data-disabled]").prop('disabled', false);
        }, 2000);
    });
}

function GET_DATA_STEAM(){
    GET_STEAM_ID(function (steamhex){
        var SteamID = require('steamid');
        var sid = new SteamID('[U:1:' + steamhex + ']');
        if(steamhex != "0x0"){
            $.ajax({
                url: "https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/?key=D6140FC42E635E983873F5247792D087&format=json&steamids=" + sid,
            }).done(function (data) {
                SteamAccount["hex"] = steamhex
                SteamAccount["avatar"] = data['response']['players'][0]['avatarfull'];
                SteamAccount["name"] = data['response']['players'][0]['personaname'];
                SteamAccount["state"] = data['response']['players'][0]['personastate'];

                SET_PROFILE();
            });
        }
    });
}

function SET_PROFILE(){
    $('.mt-profile-animated, .mt-profile-animated > .avatar, .mt-profile-animated > .name').fadeIn('fast');
    $(`[data-steam="avatar"]`).attr("src", SteamAccount["avatar"]);
    $(`[data-steam="name"]`).text(SteamAccount["name"]);
    $(`[data-steam="state"]`).removeClass("offline online away").addClass(SteamState[SteamAccount["state"]]);
    // const element = document.querySelector('.mt-profile-animated');
    // element.style.setProperty('--animate-duration', '0.5s');
    // element.classList.add('animate__animated', 'animate__fadeInDown');

    // element.addEventListener('animationend', () => {
       
    // });
    
}

function CHECK_UPDATE(){
    $.ajax({
        dataType: "json",
        url: URL_Update,
        cache: false,
        success: function(json){

            var message = `<div align="center" style="margin-bottom: 2vh;">
                                        <div class="ball-beat"><div></div><div></div><div></div></div>
                                    </div>
                                    <span class="white-text" style="font-weight: 400;font-size: 1vw;">กำลังตรวจสอบเวอร์ชั่น</span>`;
            SET_MESSAGE_ERROR(message);

            var isUpdate = false;

            var bar = new Promise((resolve, reject) => {

                $.getJSON(__dirname + "\\config.json", function(data) {
                    $.each(json, function( index, value ) {
                        var current_version = data.VERSION;
                        var check_version = index;
                        
                        if (check_version > current_version){
                            isUpdate = true;
                            console.log(isUpdate)
                            setTimeout(function(){
                                var message = `<div align="center" style="margin-bottom: 2vh;">
                                                            <div class="ball-beat"><div></div><div></div><div></div></div>
                                                        </div>
                                                        <div class="white-text" style="font-weight: 400;font-size: 1vw;">กำลังอัพเดทเวอร์ชั่น ${check_version}</div>
                                                        <div class="white-text" style="font-weight: 400;font-size: 2.5vh;" id="txt_download"></div>
                                                        <input type="hidden" id="txt_version" value="${check_version}" />`;
                                SET_MESSAGE_ERROR(message);
                            
                                if (fs.existsSync(__dirname + "\\downloads\\" + check_version + ".zip")){
                                    fs.unlinkSync(__dirname + "\\downloads\\" + check_version + ".zip");
                                }

                                //Download
                                ipcRenderer.send("download", {
                                    url: value.file,
                                    properties: {directory: __dirname + "\\downloads\\"}
                                });

                            }, 1000);
                            resolve();
                            return false;
                        } else {
                            resolve();
                        }
                    });
                }).fail(function(jqXHR, textStatus, errorThrown) {
                    var message = `<div align="center" style="margin-bottom: 2vh;">
                                                <i class="fas fa-comment-alt fa-9x"></i>
                                            </div>
                                            <span class="white-text" style="font-weight: 400;font-size: 1vw;">${errorThrown}</span>`;
                    SET_MESSAGE_ERROR(message);
                    resolve();
                });
            });

            bar.then(() => {
                if (isUpdate === false){
                    $("[data-disabled]").prop('disabled', false);

                    // setInterval(() => {
                    //     GET_DIR_TS3();
                    //     GET_DIR_GAME();
                    // }, 5000);
                    
                    CHECK_STEAM_IS_OPENNING();
                    GET_DATA_STEAM();
                }
            });

        }
    }).fail(function( jqxhr, textStatus, error) {
        var message = `<div align="center" style="margin-bottom: 2vh;">
                                    <i class="fas fa-download fa-9x"></i>
                                </div>
                                <span class="white-text" style="font-weight: 400;font-size: 1vw;">ไม่สามารถเชื่อมต่อกับเซิฟเวอร์อัพเดทได้ กรุณาลองใหม่ภายหลัง</span>`;
        SET_MESSAGE_ERROR(message);
    });
}

$(function(){

    //Notices
    $("#btn-notices").on("click", function(){
        $.ajax({
            dataType: "json",
            url: URL_Notices,
            cache: false,
            success: function(json){
                $.getJSON(__dirname + "\\config.json", function(data) {
                    localStorage.setItem(data.VERSION.toString(), true);
                    $(".notices-icon").css("color", "#fff");
                    $.alert({
                        title: `MEETA Version ${data.VERSION.toString()}`,
                        theme: 'black',
                        boxWidth: '50%',
                        draggable: false,
                        useBootstrap: false,
                        escapeKey: true,
                        backgroundDismiss: true,
                        content: `<div class="white-text">${json[data.VERSION]}</div>`,
                        buttons: {
                            upload: {
                                isHidden: true, // hide the button
                                action: function () {
            
                                }
                            }
                        }
                    });
                });
            }
        });
    });

    //Check Update
    CHECK_UPDATE();
    
    $('body').on('click', '#delete-cache', function(){
        var dir1 = DIR_GAME + "\\cache\\browser";
        var dir2 = DIR_GAME + "\\cache\\db";
        var dir3 = DIR_GAME + "\\cache\\priv";
        var dir4 = DIR_GAME + "\\cache\\servers";
        var dir5 = DIR_GAME + "\\cache\\subprocess";
        var dir6 = DIR_GAME + "\\cache\\unconfirmed"
        rimraf(dir1, function () { console.log("done"); });
        rimraf(dir2, function () { console.log("done"); });
        rimraf(dir3, function () { console.log("done"); });
        rimraf(dir4, function () { console.log("done"); });
        rimraf(dir5, function () { console.log("done"); });
        rimraf(dir6, function () { console.log("done"); });
        rimraf(DIR_GAME + "\\cache\\crashometry", function () { console.log("done"); });
        rimraf(DIR_GAME + "\\cache\\launcher_skip_mtl2", function () { console.log("done"); });
        $.alert({
            title: 'แจ้งเตือน!',
            theme: 'black',
            columnClass: 'col-md-12',
            draggable: false,
            content: 'ล้าง Cache FiveM ของคุณเรียบร้อยแล้ว',
            buttons: {
                close: {
                    btnClass: 'btn-danger',
                    text: 'ปิด', // With spaces and symbols
                    action: function () {
                        
                    }
                }
            }
        });
    });

    $('body').on('click', '#open-fivem', function(){

        if (fs.existsSync(DIR_GAME)){
            shell.openItem(DIR_GAME);
        }

    });

    $('body').on('click', '#btn-play', function(){
        var serverAdress = $(this).attr('data-game');
        var serverAdressTS3 = $(this).attr('data-ts3');
        StartFiveM(serverAdress, serverAdressTS3);
    });

     $('body').on('click', '#copy-steamId', function(){
        CopySteamId();
    });

    $('body').on('click', '#help', function(){
        shell.openExternal("https://app-meeta.io/help/");
    });



    $('body').on('click', '#btn-ts3', function(){

        var serverAdressTS3 = $(this).attr('data-ts3');

        $.ajax({
            dataType: "json",
            url: URL_Download,
            cache: false,
            success: function(json){

                IS_DISABLE_SYNC_TS3 = true;

                if (fs.existsSync(DIR_TS3) === false){

                    $("#btn-ts3").prop('disabled', true);
    
                    var url_download = `https://www.googleapis.com/drive/v3/files/${json["TS3"]["url_download"]}?key=AIzaSyBsBN2NCNfnB30mciCqM_gPC3kOoW7G7G4&alt=media`;
                    var installation_type = json["TS3"]["installation_type"];
                    var filename = json["TS3"]["filename"];

                    var dir = `${__dirname}/downloads`;

                    if (!fs.existsSync(dir)){
                        fs.mkdirSync(dir);
                    }

                    if (fs.existsSync(`${__dirname}/downloads/${filename}`)) {
                        shell.openExternal(`${__dirname}/downloads/${filename}`);
                        IS_DISABLE_SYNC_TS3 = false;
                    } else {
                        var current_freedisk = 0;
                        $("#btn-ts3").html(`<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> กำลังตรวจสอบพื้นที่ว่าง...`);

                        checkDiskSpace(__dirname).then((diskSpace) => {
                            current_freedisk = diskSpace.free;

                            setTimeout(function(){
                                $("#btn-ts3").html(`<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> กำลังเชื่อมต่อกับเซิฟเวอร์ดาวน์โหลด...`);
                            }, 3000);
  
                        })
                        
    
                        remote_file(url_download, function(err, o) {

                            var filesize = o;
    
                            if (current_freedisk >= filesize) {
                                var outStream = fs.createWriteStream(`${__dirname}/downloads/${filename}`);
        
                                progress(request(url_download), {
        
                                }).on('progress', function (state) {
                                    $("#btn-ts3").html(`<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> กำลังดาวน์โหลด ${Math.round( state.percent * 100 )}%`);
                                }).on('error', function (err) {
                                    $.alert({
                                        title: 'แจ้งเตือน',
                                        theme: 'black',
                                        columnClass: 'col-md-12',
                                        draggable: false,
                                        content: `พบข้อมูลผิดพลาด ${error}`,
                                        buttons: {
                                            close: {
                                                btnClass: 'btn-danger',
                                                text: 'ปิด', // With spaces and symbols
                                                action: function () {
                                                    
                                                }
                                            }
                                        }
                                    });
                                    $("#btn-ts3").prop('disabled', false);
                                    IS_DISABLE_SYNC_TS3 = false;
                                }).on('end', function () {
                                    $("#btn-ts3").html(`<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> กำลังดาวน์โหลด 100%`);
                                    setTimeout(function(){
                                        $("#btn-ts3").html(`<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> กำลังติดตั้ง...`);
                                        
                                        if (installation_type === "exe") {
                                            shell.openExternal(`${__dirname}/downloads/${filename}`);
                                            IS_DISABLE_SYNC_TS3 = false;
                                        }
        
                                    }, 2000);
                                }).pipe(outStream);
                            } else {
                                $.alert({
                                    title: 'แจ้งเตือน',
                                    theme: 'black',
                                    columnClass: 'col-md-12',
                                    draggable: false,
                                    content: `พื้นที่ของคุณไม่เพียงพอ ไฟล์ดาวน์โหลดขนาด ${formatBytes(filesize)} คุณเหลือพื้นที่ว่าง ${formatBytes(current_freedisk)}`,
                                    buttons: {
                                        close: {
                                            btnClass: 'btn-danger',
                                            text: 'ปิด', // With spaces and symbols
                                            action: function () {
                                                
                                            }
                                        }
                                    }
                                });
                                $("#btn-ts3").prop('disabled', false);
                                IS_DISABLE_SYNC_TS3 = false;
                            }
    
                        });
                    }
    
                   

                }else{
                    if (fs.existsSync(homedir + "\\AppData\\Roaming\\TS3Client\\plugins\\tokovoip_win64.dll")) {
                        StartTeamSpeak(serverAdressTS3);
                        $("#btn-ts3").prop('disabled', true);
                        setTimeout(function(){
                            $("#btn-ts3").prop('disabled', false);
                        }, 2000);
                    }else{
                        $("#btn-ts3").prop('disabled', true);
                        find('name', 'ts3client_win64.exe').then(function (list) {
                            if(list.length == 1){
                                $.alert({
                                    title: 'แจ้งเตือน!',
                                    theme: 'black',
                                    columnClass: 'col-md-12',
                                    draggable: false,
                                    content: 'คุณต้องปิด Teamspeak 3 ก่อนติดตั้ง TokoVoip',
                                    buttons: {
                                        close: {
                                            btnClass: 'btn-danger',
                                            text: 'ปิด', // With spaces and symbols
                                            action: function () {
                                                
                                            }
                                        }
                                    }
                                });
                                setTimeout(function(){
                                    TEXT_BUTTON_TS3 = "ติดตั้ง TokoVoip (Teamspeak 3)";
                                    $("#btn-ts3").html('<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> ' + TEXT_BUTTON_TS3);
                                    $("#btn-ts3").prop('disabled', false);
                                }, 2000);
                            }else{

                                $("#btn-ts3").prop('disabled', true);
    
                                var url_download = `https://www.googleapis.com/drive/v3/files/${json["TokoVoip"]["url_download"]}?key=AIzaSyBsBN2NCNfnB30mciCqM_gPC3kOoW7G7G4&alt=media`;
                                var installation_type = json["TokoVoip"]["installation_type"];
                                var filename = json["TokoVoip"]["filename"];

                                var dir = `${__dirname}/downloads`;

                                if (!fs.existsSync(dir)){
                                    fs.mkdirSync(dir);
                                }

                                if (fs.existsSync(`${__dirname}/downloads/${filename}`)) {
                                    shell.openExternal(`${__dirname}/downloads/${filename}`);
                                    IS_DISABLE_SYNC_TS3 = false;
                                } else {
                                    var current_freedisk = 0;
                                    $("#btn-ts3").html(`<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> กำลังตรวจสอบพื้นที่ว่าง...`);
                    
                                    checkDiskSpace(__dirname).then((diskSpace) => {
                                        current_freedisk = diskSpace.free;
                                    })
                                    
                
                                    remote_file(url_download, function(err, o) {
                                        var filesize = o;
                
                                        if (current_freedisk >= filesize) {
                                            var outStream = fs.createWriteStream(`${__dirname}/downloads/${filename}`);
                    
                                            progress(request(url_download), {
                    
                                            }).on('progress', function (state) {
                                                $("#btn-ts3").html(`<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> กำลังดาวน์โหลด ${Math.round( state.percent * 100 )}%`);
                                            }).on('error', function (err) {
                                                $.alert({
                                                    title: 'แจ้งเตือน',
                                                    theme: 'black',
                                                    columnClass: 'col-md-12',
                                                    draggable: false,
                                                    content: `พบข้อมูลผิดพลาด ${error}`,
                                                    buttons: {
                                                        close: {
                                                            btnClass: 'btn-danger',
                                                            text: 'ปิด', // With spaces and symbols
                                                            action: function () {
                                                                
                                                            }
                                                        }
                                                    }
                                                });
                                                $("#btn-ts3").prop('disabled', false);
                                                IS_DISABLE_SYNC_TS3 = false;
                                            }).on('end', function () {
                                                $("#btn-ts3").html(`<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> กำลังดาวน์โหลด 100%`);
                                                setTimeout(function(){
                                                    $("#btn-ts3").html(`<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> กำลังติดตั้งไฟล์`);
                                                    
                                                    if (installation_type === "exe") {
                                                        shell.openExternal(`${__dirname}/downloads/${filename}`);
                                                        IS_DISABLE_SYNC_TS3 = false;
                                                    } else if (installation_type === "tokovoip") {
                                                        let spawn = require("child_process").spawn;
                                                        spawn(DIR_TS3 + "\\package_inst.exe", [`${__dirname}/downloads/${filename}`]);
                                                        $("#btn-ts3").prop('disabled', true);
                                                        IS_DISABLE_SYNC_TS3 = false;
                                                    }
                    
                                                }, 2000);
                                            }).pipe(outStream);
                                        } else {
                                            $.alert({
                                                title: 'แจ้งเตือน',
                                                theme: 'black',
                                                columnClass: 'col-md-12',
                                                draggable: false,
                                                content: `พื้นที่ของคุณไม่เพียงพอ ไฟล์ดาวน์โหลดขนาด ${formatBytes(filesize)} คุณเหลือพื้นที่ว่าง ${formatBytes(current_freedisk)}`,
                                                buttons: {
                                                    close: {
                                                        btnClass: 'btn-danger',
                                                        text: 'ปิด', // With spaces and symbols
                                                        action: function () {
                                                            
                                                        }
                                                    }
                                                }
                                            });
                                            $("#btn-ts3").prop('disabled', false);
                                            IS_DISABLE_SYNC_TS3 = false;
                                        }
                
                                    });
                                }

                                
                            }
                        });
                        
                    }
                }
            }
        });
        
    });

    $("#main_page_view").on('scroll', function(){
        var scrollTop = $(this).scrollTop();
        if (scrollTop > 5) {

            $('[data-action="view"]:not(.active)').css('opacity', 0);
            $('#navbar').css({
                "margin-top": "-10vw"
            });
            $('#main_page_view').css({
                "height": "80vh"
            });

            // set css
            var index = $('.mt-game-list').index($('.mt-game-list.active'));   

            if (index > 0) {
                var marginLeft = 3.5 * index+(index*0.5);

                $('#main_library').css({
                    "padding": "2.5vw 0vw 2.5vw 2.5vw",
                    "margin-left": -(marginLeft) + 'vw'
                },);
            } else {
                $('#main_library').css({
                    "padding": "2.5vw 0vw 2.5vw 2.5vw",
                    "margin-left": "0px"
                });
            }

            // $('#main_library').css({
            //     "padding": "2.5vw 0vw 2.5vw 2.5vw",
            // });

            $('#main_page_view').css({
                "padding": "0vw 2.5vw 2.5vw 2.5vw"
            });

            $('.mt-game-list').css({
                "width": "3.5vw",
                "height": "3.5vw"
            });
            $('.mt-game-list .logo').css({
                "width": "3vw",
                "height": "3vw"
            });
            
            $('.mt-game-list .logo .icon i').css({
                "font-size": "1.5vw"
            });

            $('.mt-game-title').css({
                "font-size": "1.3vw",
                "padding-left": "4.5vw",
                "bottom": "0.8vw",
                "width": "1000%"
            });
            
            

        } else {
            $('[data-action="view"]:not(.active)').css('opacity', 1);
            $('#navbar').css({
                "margin-top": "0px"
            });

            // set css
            var index = $('.mt-game-list').index($('.mt-game-list.active'));   

            if (index > 0) {
                var marginLeft = 8.5 * index+(index*0.5);

                $('#main_library').css({
                    "padding": "5vw 0vw 2.5vw 4.5vw",
                    "margin-left": -(marginLeft) + 'vw'
                },);
            } else {
                $('#main_library').css({
                    "padding": "5vw 0vw 2.5vw 4.5vw",
                    "margin-left": "0px"
                });
            }

            $('#main_page_view').css({
                "padding": "5vw 4.5vw 2.5vw 4.5vw"
            });

            $('.mt-game-list').css({
                "width": "8.5vw",
                "height": "8.5vw"
            });
            $('.mt-game-list .logo').css({
                "width": "8vw",
                "height": "8vw"
            });

            $('.mt-game-list.active').css({
                "width": "10.5vw",
                "height": "10.5vw"
            });
            $('.mt-game-list.active .logo').css({
                "width": "10vw",
                "height": "10vw"
            });

            $('.mt-game-list .logo .icon i').css({
                "font-size": "4vw"
            });

            $('.mt-game-title').css({
                "font-size": "1.0vw",
                "padding-left": "11.25vw",
                "bottom": "0.1vw",
                "width": "300%"
            });

        }
    });

    $('body').on('click', '[data-action="view"]', function(){

        if ($(this).hasClass("active")) {
            return;
        }

        var elem = $("#main_page_view");
        var id = $(this).attr('data-id');
        elem.fadeOut('fast');
        elem.html('');
        elem.fadeIn('fast');
        $('.game-background, .bg-left').animate({
            'opacity': '0'
        }, 200);

        $('.mt-game-list').removeClass('active');
        $('.mt-game-list').removeAttr('style');
        $('.mt-game-list .logo').removeAttr('style');
        $(this).addClass('active');

        // set css
        var index = $('.mt-game-list').index(this);   

        if (index > 0) {
            var marginLeft = 8.5 * index+(index*0.5);

            $('#main_library').animate({
                "margin-left": -(marginLeft-0) + 'vw'
            }, 200);
        } else {
            $('#main_library').animate({
                "margin-left": "0px"
            }, 200);
        }
        
        $('.mt-game-title').hide();

        $('.game-background, .bg-left').css({
            'opacity': '0'
        });
        
        setTimeout(function(){
            $(`.mt-game-title[data-id="${id}"]`).fadeIn(500).css('display', 'inline-block');
        }, 200);

        $(".loading").fadeIn('fast');
        $("[data-disabled]").prop('disabled', true);
        setTimeout(function(){
            $.ajax({
                dataType: "json",
                url: URL_Library,
                cache: false,
                success: function(data){

                    var html = '';
                    var DataList = data;
                    var value = DataList[id];

                    if (value.data) {
                        GET_DIR_GAME(value.data.registry_type, value.data.registry_directory, value.data.registry_filename);
                    }

                    if (value.ts3) {
                        GET_DIR_TS3();
                    }

                    $(".loading").fadeOut('fast');

                    if (value.background) {
                        $('body').css('background', 'transparent');
                        $('.game-background').attr('src', value.background).bind('onreadystatechange load', function(){

                            if (this.complete) {
                                $('.game-background, .bg-left').animate({
                                    'opacity': '1'
                                }, 200);
                            }
                        });
                    }
              

                    var SET_DATA = function () {

                        if (value.data && DIR_GAME)
                        {
                            

                            html += `<div class="content-action-button">
                                        <button id="btn-play" data-game="${value.data.start}" class="btn btn-outline-success btn-lg" disabled="disabled" style="border-radius: 1vw;"><i class="fad fa-play fa-lg" style="margin-right: 0.5vh"></i> เล่น</button>
                                        <button id="btn-ts3" class="btn btn-outline-primary btn-lg" disabled="disabled" style="display: none;border-radius: 1vw;"><i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> เชื่อมต่อ TeamSpeak 3</button>
                                        <button class="btn btn-outline-info btn-lg" id="dropdownMenuButton1" data-action="other_button" style="border-radius: 1vw;"><i class="fad fa-cog fa-lg" style="margin-right: 0.5vh;"></i> อื่นๆ</button>
                                        <div class="dropdown-menu dropdown-menu-inverse" aria-labelledby="dropdownMenuButton1" style="background-color: #003791 !important;z-index: 99999;">
                                            <a class="dropdown-item" id="delete-cache" href="#" draggable="false"><span>ล้าง Cache</span></a>
                                            <a class="dropdown-item" id="open-fivem" href="#" draggable="false"><span>เปิดโฟลเดอร์ FiveM</span></a>
                                            <a class="dropdown-item" id="copy-steamId" href="#" draggable="false"><span>คัดลอก Steam Id ของฉัน</span></a>
                                            <a class="dropdown-item" id="help" href="#" draggable="false"><span>ช่วยเหลือ</span></a>
                                        </div>
                                    </div><span id="steam_id"></span>`;

                            // Twitter Embed
                            if (value.twitter){
                                html += `<div class="description" style="width: 25%">${atob(value.twitter)}</div>`;
                            }

                            // Description
                            if (value.description){
                                html += `<div class="description">${atob(value.description)}</div>`;
                            }

                            // ScreenShot
                            var steam_dir = DIR_STEAM + "\\userdata\\" + SteamAccount["hex"] + "\\760\\remote\\218\\screenshots\\";
                            if (fs.existsSync(DIR_GAME) && fs.existsSync(steam_dir)){
                                html += '<div id="screenshots" style="display:inline-block">';
                                html += '<div class="library_screenshot_text">ภาพหน้าจอ <a href="#album" data-action="screenshots">ดูทั้งหมด</a></div>';
                                html += '<div class="library_screenshot_width">';

                                var files = fs.readdirSync(steam_dir);
                                
                                files = files.map(function (fileName) {
                                        return {
                                          name: fileName,
                                          time: fs.statSync(steam_dir + fileName).mtime.getTime()
                                        };
                                      })
                                      .sort(function (a, b) {
                                        return b.time - a.time; })
                                      .map(function (v) {
                                        return v.name; });
    
                                $.each(files, function(index, file) {
                                    if(file.split('.')[1] == "jpg"){
                                        html += `<img data-action="imgae_view" src="${steam_dir + file}" data-file="'${file}" class="mt-thumbnail float-left" draggable="false">`;
                                    }
                                    return index<10;
                                });

                                html += '</div>';
                                html += '</div>';

                            }

                            // Addon
                            var count = Object.keys(value.addon).length;
                            if(count >= 1){
                                html += '<div class="library_addon_text">ส่วนเสริม</div>';
                                $.each(value.addon, function( index, value ) {
                                    html += `<div class="library_addon">
                                                <div class="list" data-action="addon_view" data-id="${id}" data-addon="${index}">
                                                    <img src="${value.cover}" alt="${value.name}" class="img-thumbnail addons-view" draggable="false" style="width: 30vh;height: 17vh;border-radius:0vw;" />
                                                    <div class="title">${value.name}</div>
                                                </div>
                                            </div>`;
                                });
                            }

                            $("#main_page_view").html(html).fadeIn(200);   

                            SET_TEXT_BUTTON();

                            $('#dropdown-' + id).dropdown();
    
                            $("#btn-play").prop('disabled', true);
                            $("#btn-ts3").prop('disabled', true);

                            $("#btn-play").html('<i class="fad fa-play fa-lg" style="margin-right: 0.5vh"></i> เล่น');
                            $("#btn-ts3").html('<i class="fab fa-teamspeak" style="margin-right: 0.5vh" disabled="disabled"></i> เชื่อมต่อ TeamSpeak 3');

                            if(value.ts3){
                                $("#btn-ts3").fadeIn('fast');
                                $("#btn-play").attr("data-ts3", value.ts3.serverAdress);
                                $("#btn-ts3").attr("data-ts3", value.ts3.serverAdress);
                            }

                            GET_STEAM_HEX(function (steamhex){
                                $("#steam_id").text(steamhex);
                            });

                            setInterval(() => {
                                GET_DIR_GAME(value.data.registry_type, value.data.registry_directory, value.data.registry_filename);
                                GET_DIR_TS3();
                                SET_TEXT_BUTTON();

                                var steam_dir = DIR_STEAM + "\\userdata\\" + SteamAccount["hex"] + "\\760\\remote\\218\\screenshots\\";
                                if (fs.existsSync(DIR_GAME) && fs.existsSync(steam_dir)){
                                    $("#screenshots").html("");
                                    var html = '<div class="library_screenshot_text">ภาพหน้าจอ <a href="#album" data-action="screenshots">ดูทั้งหมด</a></div>';
                                    html += '<div class="library_screenshot_width">';

                                    var files = fs.readdirSync(steam_dir);
                                    
                                    files = files.map(function (fileName) {
                                            return {
                                            name: fileName,
                                            time: fs.statSync(steam_dir + fileName).mtime.getTime()
                                            };
                                        })
                                        .sort(function (a, b) {
                                            return b.time - a.time; })
                                        .map(function (v) {
                                            return v.name; });
        
                                    $.each(files, function(index, file) {
                                        if(file.split('.')[1] == "jpg"){
                                            html += '<img data-action="imgae_view" src="' + steam_dir + file +'" data-file="' + file + '" class="mt-thumbnail float-left" draggable="false">';
                                        }
                                        return index<10;
                                    });

                                    html += '</div>';
                                    html += '</div>';

                                    $("#screenshots").html(html);

                                }

                            }, 5000);

                            $("[data-disabled]").prop('disabled', false);

                        }
                        else
                        {
                            if (value.data) {
                                setTimeout(function(){
                                    SET_DATA();
                                }, 500);
                            } else {
                                // Twitter Embed
                                if (value.twitter){
                                    html += `<div class="description" style="width: 25%">${atob(value.twitter)}</div>`;
                                }

                                // Description
                                if (value.description){
                                    html += `<div class="description">${atob(value.description)}</div>`;
                                }

                                $("#main_page_view").html(html).fadeIn(200);   

                                
                            }
                        }

                        
                    };

                    SET_DATA();
                }
            });

        }, 1000);

        
    });

    $('body').on('click', '[data-href]', function(){
        var link = $(this).attr('data-href');
        shell.openExternal(link);
    });

    const shell = require('electron').shell;
    $('iframe').click((event) => {
            event.preventDefault();
            shell.openExternal(event.target.href);
    });

    $('body').on('click', '[data-open-gtav]', function(){
        if (fs.existsSync(DIR_GAME + "\\CitizenFX.ini")) {
            var config = ini.parse(fs.readFileSync(DIR_GAME + "\\CitizenFX.ini", 'utf-8'));
            shell.openItem(config.Game.IVPath)
        } else {
            $.alert({
                title: 'แจ้งเตือน',
                theme: 'black',
                columnClass: 'col-md-12',
                draggable: false,
                content: `#ERROR_FOLDER_NOT_FOUND Please contact Support.`,
                buttons: {
                    close: {
                        btnClass: 'btn-danger',
                        text: 'ปิด', // With spaces and symbols
                        action: function () {
                            
                        }
                    }
                }
            });
        }
    });
    
    $('body').on('click', '[data-action="addon_view"]', function(){
        var id = $(this).attr('data-id');
        var addon = $(this).attr('data-addon');
        $.ajax({
            dataType: "json",
            url: URL_Library,
            cache: false,
            success: function(data){
                DataList = data
                var value = DataList[id].addon[addon];

                var content = ``;
                var buttons = {};

                if (value.preview) {
                    content = `<iframe width="100%" height="512" src="https://www.youtube.com/embed/${value.preview}" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <div class="white-text" style="margin-top: 1vw;color: #fff !important;">${value.description}</div>`;
                    buttons = {
                        youtube: {
                            text: '<i class="fab fa-youtube"></i> ดูบน Youtube', // With spaces and symbols
                            action: function () {
                                shell.openExternal("https://www.youtube.com/watch?v=" + value.preview);
                            }
                        },
                        close: {
                            text: 'ปิด',
                            action: function () {
                                
                            }
                        }
                    }
                } else {
                    content = `<div class="white-text" style="color: #fff !important;">${value.description}</div>`;
                    buttons = {
                        close: {
                            text: 'ปิด',
                            action: function () {
                                
                            }
                        }
                    }
                }

                if(value.url_download === false){
                    $.alert({
                        title: value.name,
                        theme: 'black',
                        columnClass: 'col-md-12',
                        draggable: false,
                        smoothContent: false,
                        content: content,
                        buttons: buttons
                    });
                } else {
                    $.alert({
                        title: value.name,
                        theme: 'black',
                        columnClass: 'col-md-12',
                        draggable: false,
                        smoothContent: false,
                        content: content,
                        buttons: {
                            download: {
                                btnClass: 'btn-success',
                                text: '<i class="fas fa-download"></i> ดาวน์โหลด', // With spaces and symbols
                                action: function () {
                                    var alert = this;
                                    var btn = alert.buttons.download;
                                    var btn_close = alert.buttons.close;
                                    var current_freedisk = 0;
                                    btn.disable();
                                    btn_close.disable();

                                    btn.setText(`<i class="fas fa-download"></i> กำลังตรวจสอบ...`);

                                    var is_uninstall = false;
                                    var type = value.registry.registry_type;
                                    var dir_reg = `${type}${value.registry.registry_directory}\\${value.registry.registry_filename}`;
                                    var reg_filename = value.registry.registry_filename;

                                    var bar = new Promise((resolve, reject) => {
                                        regedit.list(dir_reg).on('data', function(entry) {
                                            var array = entry.data.values;
                                            if (array) {
                                                $.each(array, function(index) {
                                                    if (index === reg_filename) {
                                                        var json = jQuery.parseJSON(array[index].value);
                                                        var directory = json[0]["directory"];
                                                        var files = json[0]["files"];
                                                        if (fs.existsSync(directory)) {
                                                            $.each(files, function(file) {
                                                                var addon_filename = `${directory}\\${files[file]}`;
    
                                                                if (fs.existsSync(addon_filename) === false) {
                                                                    is_uninstall = false;
                                                                } else {
                                                                    is_uninstall = true;
                                                                }
    
                                                                resolve();
                                                            });
                                                        } else {
                                                            is_uninstall = false;
                                                            resolve();
                                                        }
                                                    }
                                                });
                                            } else {
                                                is_uninstall = false;
                                                resolve();
                                            }
                                        }).on('error', function(err) {
                                            is_uninstall = false;
                                            resolve();
                                        });
                                    });

                                    bar.then(() => {

                                        var dir = `${__dirname}/downloads`;

                                        if (!fs.existsSync(dir)){
                                            fs.mkdirSync(dir);
                                        }

                                        if (is_uninstall === false) {
                                            btn.setText(`<i class="fas fa-download"></i> กำลังตรวจสอบพื้นที่ว่าง...`);
    
                                            checkDiskSpace(__dirname).then((diskSpace) => {
                                                current_freedisk = diskSpace.free;
                                            })
        
                                            var url_download = `https://www.googleapis.com/drive/v3/files/${value.url_download}?key=AIzaSyBsBN2NCNfnB30mciCqM_gPC3kOoW7G7G4&alt=media`;
                                            // var url_download = `http://192.168.1.2/NVE.zip`;

                                            var setFileDir = `${__dirname}/downloads/${value.file_name}`;

                                            if (fs.existsSync(setFileDir)) {
                                                UNZIP_MOD(btn, value, regedit, alert, dir_reg, setFileDir)
                                            } else {
                                                setTimeout(function(){
                                                    request({
                                                        url: url_download,
                                                        method: "HEAD"
                                                    }, function(err, response, body) {
                                                        var filesize = response.headers['content-length'];
                                                        if (current_freedisk >= filesize) {
                                                            
                                                            var outStream = fs.createWriteStream(setFileDir);
            
                                                            progress(request(url_download), {
            
                                                            })
                                                            .on('progress', function (state) {
                                                                btn.setText(`<i class="fas fa-download"></i> กำลังดาวน์โหลด ${Math.round( state.percent * 100 )}%`);
                                                            })
                                                            .on('error', function (err) {
                                                                $.alert({
                                                                    title: 'แจ้งเตือน',
                                                                    theme: 'black',
                                                                    columnClass: 'col-md-12',
                                                                    draggable: false,
                                                                    content: `พบข้อมูลผิดพลาด ${error}`,
                                                                    buttons: {
                                                                        close: {
                                                                            btnClass: 'btn-danger',
                                                                            text: 'ปิด', // With spaces and symbols
                                                                            action: function () {
                                                                                alert.close();
                                                                            }
                                                                        }
                                                                    }
                                                                });
                                                                btn_close.enable();
                                                            }).on('end', function () {
                                                                btn.setText(`<i class="fas fa-download"></i> กำลังดาวน์โหลด 100%`);
                                                                setTimeout(function(){
                                                                    UNZIP_MOD(btn, value, regedit, alert, dir_reg, setFileDir)
                                                                }, 2000);
                                                            }).pipe(outStream);
                                                        } else {
                                                            $.alert({
                                                                title: 'แจ้งเตือน',
                                                                theme: 'black',
                                                                columnClass: 'col-md-12',
                                                                draggable: false,
                                                                content: `พื้นที่ของคุณไม่เพียงพอ ไฟล์ดาวน์โหลดขนาด ${formatBytes(filesize)} คุณเหลือพื้นที่ว่าง ${formatBytes(current_freedisk)}` ,
                                                                buttons: {
                                                                    close: {
                                                                        btnClass: 'btn-danger',
                                                                        text: 'ปิด', // With spaces and symbols
                                                                        action: function () {
                                                                            
                                                                        }
                                                                    }
                                                                }
                                                            });
                                                            btn_close.enable();
                                                        }
                                                    });
                                                }, 5000);
                                            }

                                            
                                        } else {

                                            const path = require('path');
                                            const deleteFolderRecursive = function (directoryPath) {
                                                if (fs.existsSync(directoryPath)) {
                                                    fs.readdirSync(directoryPath).forEach((file, index) => {
                                                        const curPath = path.join(directoryPath, file);
                                                        if (fs.lstatSync(curPath).isDirectory()) {
                                                        // recurse
                                                        deleteFolderRecursive(curPath);
                                                        } else {
                                                        // delete file
                                                        fs.unlinkSync(curPath);
                                                        }
                                                    });
                                                    fs.rmdirSync(directoryPath);
                                                }
                                            };

                                            var uninstall = new Promise((resolve, reject) => {
                                                regedit.list(dir_reg).on('data', function(entry) {
                                                    var array = entry.data.values;
                                                    $.each(array, function(index) {
                                                        if (index === reg_filename) {
                                                            var json = jQuery.parseJSON(array[index].value);
                                                            var directory = json[0]["directory"];
                                                            var files = json[0]["files"];
                                                            if (fs.existsSync(directory)) {
                                                                $.each(files, function(file) {
                                                                    var addon_filename = `${directory}\\${files[file]}`;
                                                                    if (fs.existsSync(addon_filename)) {

                                                                        if (fs.lstatSync(addon_filename).isDirectory()) {
                                                                            deleteFolderRecursive(addon_filename);
                                                                        } else {
                                                                            fs.unlinkSync(addon_filename);
                                                                        }

                                                                        
                                                                    }

                                                                    resolve();
                                                                });
                                                            }
                                                        }
                                                    });
                                                });
                                            });
                                            
                                            uninstall.then(() => {

                                                var reg_value_name = value.registry.registry_filename;

                                                var valuesToPut = {
                                                    [dir_reg] : {
                                                        [reg_value_name]: {
                                                            value: 0,
                                                            type: 'REG_SZ'
                                                        }
                                                    }
                                                }
                                                regedit.putValue(valuesToPut, function(err) {
                                                    $.alert({
                                                        title: 'แจ้งเตือน',
                                                        theme: 'black',
                                                        columnClass: 'col-md-12',
                                                        draggable: false,
                                                        content: `ยกเลิกการติดตั้งส่วนเสริม ${value.name} เรียบร้อยแล้ว`,
                                                        buttons: {
                                                            close: {
                                                                btnClass: 'btn-danger',
                                                                text: 'ปิด', // With spaces and symbols
                                                                action: function () {
                                                                    
                                                                }
                                                            }
                                                        }
                                                    });
                                                    alert.close();
                                                });
                                            });
                                            
                                        }
                                    });

                                    

                                    return false;
                                }
                            },
                            youtube: {
                                btnClass: 'btn-warning',
                                text: '<i class="fab fa-youtube"></i> ดูบน Youtube', // With spaces and symbols
                                action: function () {
                                    shell.openExternal("https://www.youtube.com/watch?v=" + value.preview);
                                }
                            },
                            close: {
                                btnClass: 'btn-danger',
                                text: 'ปิด', // With spaces and symbols
                                action: function () {
                                    
                                }
                            }
                        },
                        onOpenBefore: function(){

                            if (! value.preview) {
                                var btn = this.buttons.youtube;
                                btn.hide();
                            }

                            var btn = this.buttons.download;
                            if (value.registry) {
                                var type = value.registry.registry_type
                                var RegistryType = Registry.HKCU;
                                if(type == "HKLM"){
                                    RegistryType = Registry.HKLM
                                }else if(type == "HKCU"){
                                    RegistryType = Registry.HKCU
                                }else if(type == "HKCR"){
                                    RegistryType = Registry.HKCR
                                }else if(type == "HKU"){
                                    RegistryType = Registry.HKU
                                }else if(type == "HKCC"){
                                    RegistryType = Registry.HKCC
                                }
                                var dir_reg = `${type}${value.registry.registry_directory}\\${value.registry.registry_filename}`;
                                var reg_filename = value.registry.registry_filename;
                                regedit.list(dir_reg).on('data', function(entry) {
                                    var array = entry.data.values;
                                    $.each(array, function(index) {
                                        if (index === reg_filename) {
                                            var json = jQuery.parseJSON(array[index].value);
                                            var directory = json[0]["directory"];
                                            var files = json[0]["files"];
                                            if (fs.existsSync(directory)) {
                                                $.each(files, function(file) {
                                                    var addon_filename = `${directory}\\${files[file]}`;
                                                    if (fs.existsSync(addon_filename) === false) {
                                                        btn.setText(`<i class="fas fa-download"></i> ดาวน์โหลด`);
                                                        btn.enable();
                                                        return false;
                                                    } else {
                                                        btn.setText(`<i class="fas fa-trash"></i> ยกเลิกการติดตั้ง`);
                                                        btn.enable();
                                                    }
                                                });
                                            } else {
                                                btn.setText(`<i class="fas fa-download"></i> ดาวน์โหลด`);
                                                btn.enable();
                                            }
                                            return false;
                                        }
                                    });
                                }).on('error', function(err) {
                                    btn.setText(`<i class="fas fa-download"></i> ดาวน์โหลด`);
                                    btn.enable();
                                });
                            } else {
                                btn.setText(`<i class="fas fa-download"></i> ดาวน์โหลด`);
                                btn.enable();
                            }

                            
                        }
                    });
                }
            }
        });
    });

    $('body').on('click', '[data-action="other_button"]', function(){
        $.alert({
            title: "",
            theme: 'black',
            boxWidth: '50%',
            draggable: false,
            useBootstrap: false,
            escapeKey: true,
            backgroundDismiss: true,
            content: ` <div class="row" style="margin: 0;">
                                <div class="col" style="padding-left: 0;" align="center">
                                    <button type="button" class="btn btn-outline-primary btn-lg" style="border-radius: 1vw;width: 97%;padding-top: 2vw;padding-bottom: 2vw;" id="open-fivem">
                                        <i class="fad fa-folder-open fa-5x"></i>
                                        <div style="margin-top: 1vw;">เปิดโฟลเดอร์ FiveM</div>
                                    </button>
                                </div>
                                <div class="col" style="padding-left: 0;" align="center">
                                    <button type="button" class="btn btn-outline-danger btn-lg" style="border-radius: 1vw;width: 97%;padding-top: 2vw;padding-bottom: 2vw;" id="delete-cache">
                                        <i class="fad fa-trash fa-5x"></i>
                                        <div style="margin-top: 1vw;">ล้าง Cache</div>
                                    </button>
                                </div>
                                <div class="col" style="padding-left: 0;" align="center">
                                    <button type="button" class="btn btn-outline-info btn-lg" style="border-radius: 1vw;width: 97%;padding-top: 2vw;padding-bottom: 2vw;" id="copy-steamId" >
                                        <i class="fab fa-steam fa-5x"></i>
                                        <div style="margin-top: 1vw;">คัดลอก Steam Id ของฉัน</div>
                                    </button>
                                </div>
                                <div class="col" style="padding-left: 0;padding-right: 0;" align="center">
                                    <button type="button" class="btn btn-outline-success btn-lg" style="border-radius: 1vw;width: 97%;padding-top: 2vw;padding-bottom: 2vw;" id="help">
                                        <i class="fad fa-question fa-5x"></i>
                                        <div style="margin-top: 1vw;">ช่วยเหลือ</div>
                                    </button>
                                </div>
                            </div>`,
            buttons: {
                upload: {
                    isHidden: true, // hide the button
                    action: function () {

                    }
                }
            }
        });
    });

    $('body').on('click', '[data-action="imgae_view"]', function(){
        var src = $(this).attr('src');
        var filename = $(this).attr('data-file');
        $.alert({
            title: filename,
            theme: 'black',
            boxWidth: '80%',
            draggable: false,
            useBootstrap: false,
            content: '<img style="width: 100%;height: auto;object-fit: cover;" src="' + src + '" draggable="false" />',
            buttons: {
                upload: {
                    btnClass: 'btn-success',
                    text: '<i class="fas fa-cloud-upload-alt"></i> รับ URL รูปภาพ', // With spaces and symbols
                    action: function () {
                        this.buttons.upload.setText('<i class="fas fa-cloud-upload-alt"></i> กำลังอัปโหลดรูปภาพ...'); // setText for 'hello' button
                        this.buttons.upload.disable();

                        var imgur = require('imgur');

                        imgur.uploadFile(src)
                        .then(function (json) {
                            clipboardy.writeSync(json.data.link);
                            clipboardy.readSync();
                            $.alert({
                                title: 'แจ้งเตือน!',
                                theme: 'black',
                                columnClass: 'col-md-12',
                                draggable: false,
                                content: 'คัดลอก URL รูปภาพของคุณเรียบร้อยแล้ว ' + json.data.link,
                                buttons: {
                                    close: {
                                        btnClass: 'btn-danger',
                                        text: 'คัดลอก', // With spaces and symbols
                                        action: function () {
                                            
                                        }
                                    }
                                }
                            });
                        })
                        .catch(function (err) {
                            $.alert({
                                title: 'แจ้งเตือน!',
                                theme: 'black',
                                columnClass: 'col-md-12',
                                draggable: false,
                                content: "พบข้อมูลผิดพลาดระหว่างการอัปโหลดรูปภาพ กรุณาลองใหม่ภายหลัง",
                                buttons: {
                                    close: {
                                        btnClass: 'btn-danger',
                                        text: 'ปิด', // With spaces and symbols
                                        action: function () {
                                            
                                        }
                                    }
                                }
                            });
                        });

                        return false;
                       
                        // shell.openExternal("https://www.youtube.com/watch?v=" + value.preview);
                    }
                },
                fullscreen: {
                    btnClass: 'btn-info',
                    text: '<i class="fas fa-picture"></i> ดูรูปขนาดเต็ม', // With spaces and symbols
                    action: function () {
                        shell.openItem(src);
                    }
                },
                close: {
                    btnClass: 'btn-danger',
                    text: 'ปิด', // With spaces and symbols
                    action: function () {
                        
                    }
                }
            }
        });
    });
    
    $('body').on('click', '[data-action="screenshots"]', function(){
        var steam_dir = DIR_STEAM + "\\userdata\\" + SteamAccount["hex"] + "\\760\\remote\\218\\screenshots\\";
        var html = '';
        // if (fs.existsSync(DIR_GAME) && fs.existsSync(steam_dir)){

        //     var files = fs.readdirSync(steam_dir);
            
        //     files = files.map(function (fileName) {
        //                 return {
        //                     name: fileName,
        //                     time: fs.statSync(steam_dir + fileName).mtime.getTime()
        //                 };
        //             })
        //             .sort(function (a, b) {
        //             return b.time - a.time; })
        //             .map(function (v) {
        //             return v.name; });
        //     $.each(files, function(index, file) {
        //         if(file.split('.')[1] == "jpg"){
        //             html += `<div class="card text-white bg-dark" style="width: 17.5rem;display: inline-block;margin: 0.5vw">
        //                         <img src="${steam_dir}${file}" class="card-img-top" data-action="imgae_view" data-file="${file}">
        //                         <div class="card-body" align="left">
        //                             <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
        //                         </div>
        //                     </div>`;
        //         }
        //     });
        // }

        $.confirm({
            title: "รูปภาพทั้งหมดของฉัน",
            theme: 'black',
            columnClass: '100vw',
            draggable: false,
            useBootstrap: false,
            content: `<div id="gallery_test" align="center"><div class="ball-beat"><div></div><div></div><div></div></div></div>`,
            onContentReady: function () {
                setTimeout(function(){
                    // $('#gallery_test').html(html);
                    $('#gallery_test').html("");
                    if (fs.existsSync(DIR_GAME) && fs.existsSync(steam_dir)){

                        var files = fs.readdirSync(steam_dir);
                        
                        files = files.map(function (fileName) {
                                    return {
                                        name: fileName,
                                        time: fs.statSync(steam_dir + fileName).mtime.getTime()
                                    };
                                })
                                .sort(function (a, b) {
                                return b.time - a.time; })
                                .map(function (v) {
                                return v.name; });
                        $.each(files, function(index, file) {
                            if(file.split('.')[1] == "jpg"){
                                var img = $("<img />").attr({
                                    'src': `${steam_dir}${file}`,
                                    'draggable': false
                                }).addClass('card-img-top').on('load', function() {
                                    if (!this.complete || typeof this.naturalWidth == "undefined" || this.naturalWidth == 0) {
                                        // alert('broken image!');
                                    } else {
                                        $('#gallery_test').append(`<div class="card text-white bg-dark" style="width: 17.5rem;display: inline-block;margin: 0.5vw">
                                                                    <div id="gallery_${index}" data-action="imgae_view" data-file="${file}" src="${steam_dir}${file}" style="cursor:pointer"><div class="ball-beat" style="margin: 2vw;"><div></div><div></div><div></div></div></div>
                                                                    <div id="gallery_content_${index}"></div>
                                                                </div>`);
                                                                    setTimeout(function(){
                                                                        $(`#gallery_${index}`).html(img);
                                                                        $(`#gallery_content_${index}`).html(`<div class="card-body" align="left"><i class="fad fa-file-image"></i> ${file}</div>`);
                                                                    }, 500);
                                    }
                                });
                            }
                            return index<500;
                        });
                    }
                }, 2000);
            },
            buttons: {
                openfolder: {
                    btnClass: 'btn-success',
                    text: '<i class="fad fa-file-image"></i> เปิดโฟลเดอร์รูปภาพ', // With spaces and symbols
                    action: function () {
                        
                        shell.openItem(steam_dir);
                        return false;
                       
                        // shell.openExternal("https://www.youtube.com/watch?v=" + value.preview);
                    }
                },
                close: {
                    btnClass: 'btn-danger',
                    text: 'ปิด', // With spaces and symbols
                    action: function () {
                        
                    }
                }
            },
            columnClass: 'large',
        });
        
        // setTimeout(function(){
        //     $.alert({
        //         title: "รูปภาพทั้งหมดของฉัน",
        //         theme: 'black',
        //         columnClass: '600px',
        //         draggable: false,
        //         useBootstrap: false,
        //         content: html,
        //         buttons: {
        //             close: {
        //                 text: 'ปิด', // With spaces and symbols
        //                 action: function () {
                            
        //                 }
        //             }
        //         }
        //     });
        // }, 2000);
        
    });
    $("#btn-library").on('click', function(){
        $("#main_page").hide();
        $("#main_page_view").hide();
        $("#message_error").html("");
        fs.readFile(__dirname + "\\library.html", function (err, data) {
            GET_DATA_STEAM();
            $(".loading").fadeIn('fast');
            $("[data-disabled]").prop('disabled', true);
            setTimeout(function(){
                $("#main_page").hide().html(data.toString()).fadeIn('fast');
                $("#main_page_view").show();
                $("[data-disabled]").prop('disabled', false);
            }, 2000);
        });
    });

    $("#button-settings").on('click', function(){
        const electron = require('electron');
        const path = require('path');
        const BrowserWindow = electron.remote.BrowserWindow;
        const modalPath = path.join('file://', __dirname, 'settings.html');
        let win = new BrowserWindow({ 
            width: 400, 
            height: 600, 
            frame: false, 
            resizable: false, 
            skipTaskbar: true, 
            webPreferences: {
                nodeIntegration: true
            }
        });
        win.loadURL(modalPath);
        win.show();

        GET_STEAM_HEX(function (steamhex){
            win.webContents.on('did-finish-load', () => {
                if(steamhex == "0x0"){
                    win.webContents.send("steam-id", "0x0");
                }else{
                    win.webContents.send("steam-id", steamhex);
                }
            })
        });
    });

});

ipcRenderer.on("download progress", (event, progress) => {
    const cleanProgressInPercentages = Math.floor(progress.percent * 100); // Without decimal point
    $("#txt_download").text("กำลังดาวน์โหลด " + cleanProgressInPercentages + "%");
    // $(".progress-bar").css('width', cleanProgressInPercentages + '%');
    // $("#version").text(cleanProgressInPercentages+ '%');
});

ipcRenderer.on("download complete", (event, file) => {

    var DecompressZip = require('decompress-zip');
    var ZIP_FILE_PATH = file;
    var DESTINATION_PATH = __dirname;
    var unzipper = new DecompressZip(ZIP_FILE_PATH);
    
    unzipper.on('error', function (err) {
        $("#txt_download").text("ผิดพลาด: " + err);
    });
    
    unzipper.on('progress', function (fileIndex, fileCount) {
        $("#txt_download").text("กำลังติดตั้งไฟล์ " + (fileIndex + 1) + '/' + fileCount);

        if((fileIndex + 1) == fileCount){ //Extract Success


            fs.readFile(__dirname + "//config.json", 'utf8', function readFileCallback(err, data){
                if (err){
                    console.log(err);
                } else {
                obj = JSON.parse(data); //now it an object
                obj.VERSION = $("#txt_version").val();
                json = JSON.stringify(obj, null, 4); //convert it back to json
                fs.writeFile(__dirname + "//config.json", json, 'utf8', err => {
                    if (err) return console.error('File write error:', err);
                });
            }});

            setTimeout(function(){
                fs.unlinkSync(file);
                const {app} = require('electron').remote;
                app.relaunch();
                app.exit();
            }, 2000);
        }

    });

    unzipper.extract({
        path: DESTINATION_PATH
    });
    
});

// unzipper.on('error', function (err) {
//     $("#message").text("Error: " + err);
// });

// unzipper.on('progress', function (fileIndex, fileCount) {
//     $("#message").text("���ѧ�Դ������  " + (fileIndex + 1) + ' of ' + fileCount);
// });

//END UPDATE

function AppMaximize(){
    const remote = require('electron').remote;
    var win = remote.getCurrentWindow();
    win.minimize();
}

function AppClosed(){
    const remote = require('electron').remote.app;
    // let w = remote.getCurrentWindow();
    // w.close();
    remote.quit();
}

function StartFiveM(ip, ts3){

    $("#button-start").attr('disabled','disabled');
    $("#button-start").text('CHECKING...');

    $.getJSON("config.json", function(json) {
        for (i = 0; i < json["check"].files.length; i++) {

            var FILE_NAME = json["check"].files[i];
            var FOLDER_NAME = json["check"].folder;
            var DIR_TARGET = DIR_GAME; //+ DIR_NAME + "\\";

            if(!fs.existsSync(DIR_TARGET + FILE_NAME)) {
                var fss = require('fs-extra');
                fss.copy(__dirname + "\\files\\" + FOLDER_NAME, DIR_TARGET); 

                StartFiveM_2(ip, ts3);

                break;
            }else{
                StartFiveM_2(ip, ts3)
            }
        }
    });
}

function run_script(command, args, callback) {
    //https://stackoverflow.com/questions/57054359/run-cmd-exe-and-make-some-command-with-electron-js
    var child = child_process.spawn(command, args, {
        encoding: 'utf8',
        shell: true
    });
    // You can also use a variable to save the output for when the script closes later
    child.on('error', (error) => {
        console.log('Error occured.\r\n' + error);
    });

    child.stdout.setEncoding('utf8');
    child.stdout.on('data', (data) => {
        //Here is the output
        data=data.toString();   
        console.log(data);      
    });

    child.stderr.setEncoding('utf8');
    child.stderr.on('data', (data) => {
        // Return some data to the renderer process with the mainprocess-response ID
        // mainWindow.webContents.send('mainprocess-response', data);
        //Here is the output from the command
        console.log(data);  
    });

    child.on('close', (code) => {
        //Here you can get the exit code of the script  
        switch (code) {
            case 0:
                console.log('End process.\r\n');
                break;
        }

    });
    if (typeof callback === 'function')
        callback();
}

function StartFiveM_2(ip, ts3){
    $.getJSON("config.json", function(json) {
        var dir_replace = DIR_GAME.replace("FiveM.app\\", ``);
        if (fs.existsSync(dir_replace)){
            run_script(dir_replace + "FiveM.exe", [`${atob(ip)}`], null)
        }
        if (ts3) {
            StartTeamSpeak(ts3);
        }
        setTimeout(function(){
            $("#button-start").prop("disabled", false);
            $("#button-start").text('START GAME');
        }, 5000);
    });
}

function StartTeamSpeak(ts3){
    $.getJSON("config.json", function(json) {
        var ts_frame = document.createElement('iframe');
        ts_frame.style.display = 'none';
        ts_frame.onload = function() { ts_frame.parentNode.removeChild(ts_frame); };
        ts_frame.src = atob(ts3);
        document.body.appendChild(ts_frame);
    });
}

function d2h(s) {
    var a = s.toString(16);
    if ((a.length % 2) > 0) {
        a = "0" + a;
    }
    return a;
}

function SET_TEXT_BUTTON(){

    var TEXT_BUTTON_PLAY = "เล่น";;
    var TEXT_BUTTON_TS3 = "เชื่อมต่อ Teamspeak 3";
    $("#btn-play").prop('disabled', true);
    $("#btn-ts3").prop('disabled', true);

    $.getJSON("config.json", function(json) {
        if (!fs.existsSync(DIR_GAME)){
            $("#btn-play").prop('disabled', true);
            $("#dropdownMenuButton1").prop('disabled', true);
            TEXT_BUTTON_PLAY = "ยังไม่ได้ติดตั้ง FiveM";
        }else{
            $("#btn-play").prop('disabled', false);
            $("#dropdownMenuButton1").prop('disabled', false);
            TEXT_BUTTON_PLAY = "เล่น";
        }

        $("#btn-play").html('<i class="fad fa-play fa-lg" style="margin-right: 0.5vh"></i> ' + TEXT_BUTTON_PLAY);

        if (IS_DISABLE_SYNC_TS3 === false){
            if (fs.existsSync(DIR_TS3) === false){
                find('name', json["add-on"]["teamspeak3"]["filename"]).then(function (list) {
                    if(list.length == 1){
                        TEXT_BUTTON_TS3 = "กำลังติดตั้ง Teamspeak 3";
                        $("#btn-ts3").prop('disabled', true);
                    }else{
                        TEXT_BUTTON_TS3 = "ติดตั้ง Teamspeak 3";
                        $("#btn-ts3").prop('disabled', false);
                    }
                    $("#btn-ts3").html('<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> ' + TEXT_BUTTON_TS3);
                }, function (err) {
                    TEXT_BUTTON_TS3 = "ติดตั้ง Teamspeak 3";
                    $("#btn-ts3").html('<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> ' + TEXT_BUTTON_TS3);
                    $("#btn-ts3").prop('disabled', false);
                });
            }else{
                if (fs.existsSync(homedir + "\\AppData\\Roaming\\TS3Client\\plugins\\tokovoip_win64.dll")) {
                    TEXT_BUTTON_TS3 = "เชื่อมต่อ Teamspeak 3";
                    $("#btn-ts3").prop('disabled', false);
                }else{
                    TEXT_BUTTON_TS3 = "ติดตั้ง TokoVoip (Teamspeak 3)";
                    $("#btn-ts3").prop('disabled', false);
                }
                $("#btn-ts3").html('<i class="fab fa-teamspeak" style="margin-right: 0.5vh"></i> ' + TEXT_BUTTON_TS3);
            }
        }
    });

    
    
}

const extract = require('extract-zip')
 
async function unzipFile(file, dir, btn, value, regedit, alert, dir_reg, setFileDir, installation_dir) {
    try {
        await extract(file, { dir: dir })
        Extract_Compelete(btn, value, regedit, alert, dir_reg, setFileDir, installation_dir);
    } catch (err) {
        console.log(err)
    }
}

function Extract_Compelete(btn, value, regedit, alert, dir_reg, setFileDir, installation_dir) {
    var zip = new AdmZip(setFileDir);
    var reg_value_name = value.registry.registry_filename;
    
    var zipEntries = zip.getEntries();
    var listfile = [];
    var fileplush = [];

    
    zipEntries.forEach(function(zipEntry) {
        listfile.push(zipEntry.entryName);
    });
    fileplush.push({
        directory: installation_dir,
        files: listfile
    });
    var valuesToPut = {
        [dir_reg] : {
            [reg_value_name]: {
                value: JSON.stringify(fileplush),
                type: 'REG_SZ'
            }
        }
    }
    regedit.putValue(valuesToPut, function(err) {
        if (err) {
            $.alert({
                title: 'แจ้งเตือน',
                theme: 'black',
                columnClass: 'col-md-12',
                draggable: false,
                content: `#Registry02 พบข้อมูลผิดพลาด ${err}`,
                buttons: {
                    close: {
                        btnClass: 'btn-danger',
                        text: 'ปิด', // With spaces and symbols
                        action: function () {
                            
                        }
                    }
                }
            });
        } else {
            $.alert({
                title: 'แจ้งเตือน',
                theme: 'black',
                columnClass: 'col-md-12',
                draggable: false,
                content: `ติดตั้งส่วนเสริม ${value.name} เสร็จเรียบร้อยแล้ว`,
                buttons: {
                    close: {
                        btnClass: 'btn-danger',
                        text: 'ปิด', // With spaces and symbols
                        action: function () {
                            
                        }
                    }
                }
            });

            fs.unlinkSync(setFileDir);

            alert.close();

        }
        
    });
}

async function UNZIP_MOD(btn, value, regedit, alert, dir_reg, setFileDir) {

    btn.setText(`<i class="fas fa-download"></i> กำลังติดตั้งไฟล์`);
            
    if (value.registry) {
        regedit.createKey([dir_reg], function(err) {
            if (err) {
                $.alert({
                    title: 'แจ้งเตือน',
                    theme: 'black',
                    columnClass: 'col-md-12',
                    draggable: false,
                    content: `#Registry01 พบข้อมูลผิดพลาด ${err}`,
                    buttons: {
                        close: {
                            btnClass: 'btn-danger',
                            text: 'ปิด', // With spaces and symbols
                            action: function () {
                                alert.close();
                            }
                        }
                    }
                });
                return false;
            } else {
                
                var installation_game  = value.installation_game;
                var installation_dir  = ``;
                
                if (installation_game === "FiveM") {
                    installation_dir = DIR_GAME + value.installation_directory;

                    if (!fs.existsSync(installation_dir)){
                        fs.mkdirSync(installation_dir);
                    }

                    if (!fs.existsSync(DIR_GAME)) {
                        $.alert({
                            title: 'แจ้งเตือน',
                            theme: 'black',
                            columnClass: 'col-md-12',
                            draggable: false,
                            content: `คุณยังไม่ได้ติดตั้ง FiveM`,
                            buttons: {
                                close: {
                                    btnClass: 'btn-danger',
                                    text: 'ปิด', // With spaces and symbols
                                    action: function () {
                                        alert.close();
                                    }
                                }
                            }
                        });
                        return false;
                    }

                } else if (installation_game === "GTAV") {
                    if (fs.existsSync(DIR_GAME + "\\CitizenFX.ini")) {
                        var config = ini.parse(fs.readFileSync(DIR_GAME + "\\CitizenFX.ini", 'utf-8'));
                        installation_dir = `${config.Game.IVPath}\\${value.installation_directory}`;

                        if (!fs.existsSync(installation_dir)){
                            fs.mkdirSync(installation_dir);
                        }

                        if (!fs.existsSync(config.Game.IVPath)) {
                            $.alert({
                                title: 'แจ้งเตือน',
                                theme: 'black',
                                columnClass: 'col-md-12',
                                draggable: false,
                                content: `คุณยังไม่ได้ติดตั้ง Grand Theft Auto V`,
                                buttons: {
                                    close: {
                                        btnClass: 'btn-danger',
                                        text: 'ปิด', // With spaces and symbols
                                        action: function () {
                                            alert.close();
                                        }
                                    }
                                }
                            });
                            return false;
                        }

                    } else {
                        $.alert({
                            title: 'แจ้งเตือน',
                            theme: 'black',
                            columnClass: 'col-md-12',
                            draggable: false,
                            content: `คุณยังไม่ได้ติดตั้ง FiveM`,
                            buttons: {
                                close: {
                                    btnClass: 'btn-danger',
                                    text: 'ปิด', // With spaces and symbols
                                    action: function () {
                                        alert.close();
                                    }
                                }
                            }
                        });
                        return false;
                    }
                }

                unzipFile(setFileDir, installation_dir, btn, value, regedit, alert, dir_reg, setFileDir, installation_dir)
            }
        })
    }
}